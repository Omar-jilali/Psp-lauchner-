package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Un émulateur connu + les consoles pour lesquelles il est recommandé. */
data class Emu(
    val name: String,
    val pkg: String,
    val activity: String? = null,
    val platforms: Set<String> = emptySet(),
)

object Emulators {
    val known = listOf(
        Emu("PPSSPP Gold (PSP)", "org.ppsspp.ppssppgold", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("PPSSPP (PSP)", "org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("DuckStation (PS1)", "com.github.stenzek.duckstation", null, setOf("PS1")),
        Emu("NetherSX2 / AetherSX2 (PS2)", "xyz.aethersx2.android", null, setOf("PS2")),
        Emu("Dolphin (GameCube / Wii)", "org.dolphinemu.dolphinemu", null, setOf("GameCube", "Wii")),
        Emu("Flycast (Dreamcast)", "com.flycast.emulator", null, setOf("Dreamcast")),
    )

    fun isInstalled(ctx: Context, e: Emu): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(e.pkg) != null

    fun installed(ctx: Context): List<Emu> = known.filter { isInstalled(ctx, it) }

    /** La "porte" : lance l'émulateur avec l'ISO. false si ça échoue. */
    fun launch(ctx: Context, e: Emu, iso: Uri): Boolean {
        val i = Intent(Intent.ACTION_VIEW).apply {
            if (e.activity != null) setClassName(e.pkg, e.activity) else setPackage(e.pkg)
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching { ctx.startActivity(i) }.isSuccess
    }

    /** Laisse Android proposer toutes les apps capables d'ouvrir le fichier. */
    fun chooser(ctx: Context, iso: Uri): Boolean {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return runCatching {
            ctx.startActivity(Intent.createChooser(i, "Ouvrir avec…"))
        }.isSuccess
    }

    // ---- Choix mémorisé, une console à la fois (PSP -> PPSSPP, PS2 -> NetherSX2...)
    private fun key(platform: String) = "emu_$platform"

    fun savedPkg(ctx: Context, platform: String): String? =
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString(key(platform), null)

    fun save(ctx: Context, platform: String, pkg: String?) {
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().apply {
            if (pkg == null) remove(key(platform)) else putString(key(platform), pkg)
        }.apply()
    }
}

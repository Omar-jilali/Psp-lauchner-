package com.you.pspl.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CrashScreen(text: String, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("L'app a planté la dernière fois", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = { clip.setText(AnnotatedString(text)) }) { Text("Copier l'erreur") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onDismiss) { Text("Continuer") }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text.take(4000), fontSize = 11.sp,
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        )
    }
}

@Composable
fun LoadingScreen() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        androidx.compose.material3.CircularProgressIndicator()
        Spacer(Modifier.height(12.dp))
        Text("Analyse des jeux…")
    }
}

@Composable
fun EmptyScreen(scanned: Boolean, errors: List<String>, onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            if (scanned) "Aucun jeu .iso trouvé dans ce dossier." else "Bienvenue !",
            fontSize = 20.sp, fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(14.dp))
        Button(onClick = onPick) { Text("Choisir le dossier des ISO") }
        if (errors.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text(errors.take(5).joinToString("\n"), fontSize = 11.sp)
        }
    }
}

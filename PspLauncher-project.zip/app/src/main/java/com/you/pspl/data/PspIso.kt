package com.you.pspl.data

import android.content.Context
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

private const val SECTOR = 2048L

private data class Entry(val lba: Long, val size: Long, val isDir: Boolean)

/** Lecteur minimal ISO9660 en accès aléatoire (ne charge pas l'ISO en RAM). */
class PspIso(context: Context, uri: Uri) : AutoCloseable {
    private val pfd = context.contentResolver.openFileDescriptor(uri, "r")
        ?: error("Impossible d'ouvrir $uri")
    private val ch: FileChannel = FileInputStream(pfd.fileDescriptor).channel
    private val root: Entry

    init {
        val pvd = read(16 * SECTOR, SECTOR.toInt())
        require(String(pvd, 1, 5) == "CD001") { "Pas une ISO9660" }
        root = parseRecord(pvd, 156)!!
    }

    private fun read(pos: Long, len: Int): ByteArray {
        val buf = ByteBuffer.allocate(len)
        var p = pos
        while (buf.hasRemaining()) {
            val n = ch.read(buf, p)
            if (n <= 0) break
            p += n
        }
        return buf.array()
    }

    private fun le32(b: ByteArray, o: Int) =
        ByteBuffer.wrap(b, o, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL

    private fun parseRecord(b: ByteArray, o: Int): Entry? {
        if (b[o].toInt() == 0) return null
        return Entry(le32(b, o + 2), le32(b, o + 10), (b[o + 25].toInt() and 2) != 0)
    }

    private fun find(dir: Entry, name: String): Entry? {
        val data = read(dir.lba * SECTOR, dir.size.toInt())
        var o = 0
        while (o < data.size) {
            val len = data[o].toInt() and 0xFF
            if (len == 0) { o = ((o / SECTOR.toInt()) + 1) * SECTOR.toInt(); continue }
            val nl = data[o + 32].toInt() and 0xFF
            val n = String(data, o + 33, nl, Charsets.ISO_8859_1).substringBefore(';')
            if (n.equals(name, ignoreCase = true)) return parseRecord(data, o)
            o += len
        }
        return null
    }

    /** ex: readFile("PSP_GAME/ICON0.PNG") ; null si absent. */
    fun readFile(path: String): ByteArray? {
        var cur = root
        val parts = path.split('/')
        for ((i, p) in parts.withIndex()) {
            cur = find(cur, p) ?: return null
            if (i < parts.lastIndex && !cur.isDir) return null
        }
        return if (cur.isDir) null else read(cur.lba * SECTOR, cur.size.toInt())
    }

    override fun close() { ch.close(); pfd.close() }
}

/** Parse PARAM.SFO -> map clé/valeur (TITLE, DISC_ID, ...). */
fun parseSfo(b: ByteArray): Map<String, String> {
    val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
    require(b.size > 20 && bb.getInt(0) == 0x46535000) { "SFO invalide" } // "\0PSF"
    val keyTable = bb.getInt(8)
    val dataTable = bb.getInt(12)
    val count = bb.getInt(16)
    val out = LinkedHashMap<String, String>()
    for (i in 0 until count) {
        val e = 20 + i * 16
        val keyOff = bb.getShort(e).toInt() and 0xFFFF
        val fmt = bb.getShort(e + 2).toInt() and 0xFFFF
        val len = bb.getInt(e + 4)
        val dataOff = bb.getInt(e + 12)
        var k = keyTable + keyOff
        val ks = k
        while (b[k].toInt() != 0) k++
        val key = String(b, ks, k - ks, Charsets.US_ASCII)
        val dStart = dataTable + dataOff
        out[key] = when (fmt) {
            0x0004, 0x0204 -> String(b, dStart, len, Charsets.UTF_8).trimEnd('\u0000')
            0x0404 -> bb.getInt(dStart).toString()
            else -> ""
        }
    }
    return out
}

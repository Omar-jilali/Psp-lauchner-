package com.you.pspl.data

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Une bibliothèque = une console + son émulateur. Le libellé est celui affiché dans la barre du haut. */
enum class Platform(val label: String, val gameDir: String, val idKey: String, val emulator: String) {
    PSP("GAMES IOS PSP", "PSP_GAME", "DISC_ID", "PPSSPP"),
    PS3("GAMES IOS PS3", "PS3_GAME", "TITLE_ID", "aPS3e"),
}

data class Game(
    val platform: Platform,
    val title: String,
    val id: String,        // DISC_ID (PSP) / TITLE_ID (PS3)
    val key: String,       // clé de cache stable (uri + date + taille)
    val uri: Uri,          // ISO, ou dossier du jeu (PS3)
    val icon: File?,
    val background: File?,
    val music: File?,      // SND0.AT3 brut, converti en m4a à la volée
    val dir: File,         // dossier de cache de ce jeu
)

class Library(val platform: Platform) {
    var games by mutableStateOf(listOf<Game>())
    var loading by mutableStateOf(false)
    var hasFolder by mutableStateOf(false)
}

package com.you.pspl.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import kotlin.math.PI
import kotlin.math.sin

private val TWO_PI = (2.0 * PI).toFloat()

/** Un élément de la liste verticale (un jeu, un réglage, un émulateur...). */
class XmbItem(
    val icon: File?,
    val glyph: String,
    val title: String,
    val subtitle: String,
    val badge: String?,
    val onActivate: () -> Unit,
)

/** Clic sans effet d'ondulation (plus proche de la PS3). */
@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick,
    )

// ------------------------------------------------------------------ Fond

@Composable
fun XmbBackground(bg: File?) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f,
        targetValue = TWO_PI,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "phase",
    )
    val stars = remember {
        val r = java.util.Random(7)
        List(70) {
            floatArrayOf(r.nextFloat(), r.nextFloat(), 0.8f + r.nextFloat() * 1.8f, r.nextFloat() * TWO_PI)
        }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.linearGradient(
                    listOf(Color(0xFF6B3C12), Color(0xFF8A5C20), Color(0xFFA67F36)),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height),
                )
            )
        }
        // L'image du jeu apparaît très discrètement derrière la vague
        Crossfade(targetState = bg, label = "bgimg") { f ->
            AsyncImage(
                model = f, contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 0.22f },
                contentScale = ContentScale.Crop,
            )
        }
        Canvas(Modifier.fillMaxSize()) {
            drawWaves(phase)
            drawStars(stars, phase)
        }
    }
}

private fun DrawScope.drawWaves(phase: Float) {
    val w = size.width
    val h = size.height
    val steps = 40
    for (k in 0 until 4) {
        val baseY = h * (0.52f + 0.03f * k)
        val amp = h * (0.075f - 0.012f * k)
        val dir = if (k % 2 == 0) 1f else -1f

        fun top(x: Float): Float {
            val u = x / w
            return baseY +
                amp * sin(u * TWO_PI * 0.9f + dir * phase + k * 0.8f) +
                amp * 0.4f * sin(u * TWO_PI * 1.7f - dir * phase * 2f)
        }
        fun thick(x: Float): Float = h * (0.035f + 0.02f * sin(x / w * TWO_PI * 0.6f + k))

        val ribbon = Path()
        ribbon.moveTo(0f, top(0f))
        for (s in 1..steps) {
            val x = w * s / steps
            ribbon.lineTo(x, top(x))
        }
        for (s in steps downTo 0) {
            val x = w * s / steps
            ribbon.lineTo(x, top(x) + thick(x))
        }
        ribbon.close()
        drawPath(
            ribbon,
            Brush.verticalGradient(
                colors = listOf(Color(0x00FFF3D6), Color(0x66FFF3D6), Color(0x00FFE9B8)),
                startY = baseY - amp,
                endY = baseY + amp + h * 0.06f,
            ),
        )

        val edge = Path()
        edge.moveTo(0f, top(0f))
        for (s in 1..steps) {
            val x = w * s / steps
            edge.lineTo(x, top(x))
        }
        drawPath(edge, Color(0x55FFFFFF), style = Stroke(width = 1.5f))
    }
}

private fun DrawScope.drawStars(stars: List<FloatArray>, phase: Float) {
    for (s in stars) {
        val a = 0.25f + 0.55f * (0.5f + 0.5f * sin(phase * 2f + s[3]))
        drawCircle(
            Color(0xFFFFF1CC).copy(alpha = a),
            radius = s[2],
            center = Offset(size.width * s[0], size.height * s[1]),
        )
    }
}

// ------------------------------------------------------------------ Catégories

@Composable
fun CatIcon(
    glyph: String,
    label: String,
    selected: Boolean,
    centerX: Dp,
    y: Dp,
    onClick: () -> Unit,
) {
    val x by animateDpAsState(centerX, label = "cx")
    val scale by animateFloatAsState(if (selected) 1.3f else 0.85f, label = "cs")
    val glyphAlpha by animateFloatAsState(if (selected) 1f else 0.55f, label = "ca")
    val labelAlpha by animateFloatAsState(if (selected) 1f else 0f, label = "cl")
    Column(
        Modifier.offset(x = x - 45.dp, y = y).width(90.dp).tap(onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            glyph, fontSize = 34.sp, color = Color.White,
            modifier = Modifier.graphicsLayer {
                scaleX = scale; scaleY = scale; alpha = glyphAlpha
            },
        )
        Text(
            label, fontSize = 13.sp, color = Color.White, maxLines = 1,
            modifier = Modifier.padding(top = 6.dp).graphicsLayer { alpha = labelAlpha },
        )
    }
}

// ------------------------------------------------------------------ Lignes de la liste

@Composable
fun XmbRow(
    item: XmbItem,
    selected: Boolean,
    below: Boolean,        // false pour les éléments au-dessus de la sélection (ils disparaissent)
    anchorX: Dp,
    top: Dp,
    rowWidth: Dp,
    onClick: () -> Unit,
) {
    val y by animateDpAsState(top, label = "top")
    val iw by animateDpAsState(if (selected) 112.dp else 60.dp, label = "iw")
    val rowAlpha by animateFloatAsState(
        if (!below) 0f else if (selected) 1f else 0.8f, label = "ra"
    )
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(260)) }

    Row(
        Modifier
            .offset(x = anchorX - 64.dp, y = y)
            .width(rowWidth)
            .graphicsLayer { alpha = rowAlpha * appear.value }
            .tap(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(128.dp).height(66.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.width(iw).height(iw * (80f / 144f))
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x22FFFFFF)),
                contentAlignment = Alignment.Center,
            ) {
                if (item.icon != null) {
                    AsyncImage(
                        model = item.icon, contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(item.glyph, fontSize = if (selected) 32.sp else 22.sp, color = Color.White)
                }
            }
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(
                item.title, color = Color.White,
                fontSize = if (selected) 20.sp else 15.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (selected) {
                Text(
                    item.subtitle, color = Color(0xCCFFFFFF), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (selected && item.badge != null) {
            Box(
                Modifier.clip(RoundedCornerShape(3.dp))
                    .background(Color(0xAA8A8A8A))
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(item.badge, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

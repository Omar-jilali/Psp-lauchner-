package com.you.pspl.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sin

private val TWO_PI = (2.0 * PI).toFloat()

/** Un élément de la liste verticale (un jeu, un réglage, un émulateur...). */
class XmbItem(
    val icon: File?,
    val kind: CatKind?,
    val title: String,
    val subtitle: String,
    val badge: String?,
    val onActivate: () -> Unit,
)

/** Clic sans effet d'ondulation (plus proche de la PS3). */
@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick,
    )

// ------------------------------------------------------------------ Fond animé

@Composable
fun XmbBackground() {
    val t = rememberInfiniteTransition(label = "silk")
    val phase by t.animateFloat(
        initialValue = 0f,
        targetValue = TWO_PI,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing)),
        label = "phase",
    )
    val drift by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(70000, easing = LinearEasing)),
        label = "drift",
    )
    val particles = remember {
        val r = java.util.Random(11)
        List(110) {
            floatArrayOf(
                r.nextFloat(), r.nextFloat(),
                0.7f + r.nextFloat() * 1.9f,
                r.nextFloat() * TWO_PI,
                if (r.nextInt(3) == 0) 2f else 1f,
            )
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        // Teinte dorée / ocre / brune
        drawRect(
            Brush.linearGradient(
                listOf(Color(0xFF6E4015), Color(0xFF84571F), Color(0xFF9C7430)),
                start = Offset(0f, size.height * 0.2f),
                end = Offset(size.width, size.height * 0.9f),
            )
        )
        drawSilk(phase)
        drawParticles(particles, phase, drift)
    }
}

/** Larges rubans translucides qui montent en diagonale (bas-gauche -> haut-droit). */
private fun DrawScope.drawSilk(phase: Float) {
    val w = size.width
    val h = size.height
    val m = minOf(w, h)
    val sx = -0.15f * w
    val sy = 1.05f * h
    val dx = 1.30f * w
    val dy = -1.10f * h
    val len = hypot(dx, dy)
    val ux = dx / len
    val uy = dy / len
    val nx = -uy
    val ny = ux
    val n = 56
    val cx = FloatArray(n + 1)
    val cy = FloatArray(n + 1)
    val wd = FloatArray(n + 1)
    val widths = floatArrayOf(0.34f, 0.26f, 0.20f, 0.30f)
    val amps = floatArrayOf(0.10f, 0.08f, 0.07f, 0.09f)
    val alphas = floatArrayOf(0.55f, 0.75f, 0.90f, 0.60f)
    val pi = PI.toFloat()

    for (k in 0 until 4) {
        val off = m * (-0.30f + 0.22f * k)
        val dirK = if (k % 2 == 0) 1f else -1f
        for (i in 0..n) {
            val t = i / n.toFloat()
            val lat = off +
                m * amps[k] * sin(TWO_PI * (1.1f + 0.2f * k) * t + dirK * phase + k) +
                m * amps[k] * 0.5f * sin(TWO_PI * 2.3f * t - 2f * dirK * phase + k * 1.7f)
            cx[i] = sx + dx * t + nx * lat
            cy[i] = sy + dy * t + ny * lat
            wd[i] = m * widths[k] * (0.35f + 0.65f * sin(pi * t)) *
                (0.8f + 0.2f * sin(TWO_PI * 1.3f * t + phase + k * 2f))
        }
        val ribbon = Path()
        ribbon.moveTo(cx[0] + nx * wd[0] / 2f, cy[0] + ny * wd[0] / 2f)
        for (i in 1..n) ribbon.lineTo(cx[i] + nx * wd[i] / 2f, cy[i] + ny * wd[i] / 2f)
        for (i in n downTo 0) ribbon.lineTo(cx[i] - nx * wd[i] / 2f, cy[i] - ny * wd[i] / 2f)
        ribbon.close()

        // La lumière glisse le long du ruban (boucle sans coupure grâce au mode Mirror)
        val gradLen = len * (0.45f + 0.08f * k)
        val shift = phase / TWO_PI * (gradLen * 2f)
        val s0 = Offset(sx + ux * shift, sy + uy * shift)
        val s1 = Offset(s0.x + ux * gradLen, s0.y + uy * gradLen)
        drawPath(
            ribbon,
            Brush.linearGradient(
                0f to Color(0x10FFEFD0),
                0.5f to Color(0x70FFF4DE),
                1f to Color(0x18F0C070),
                start = s0, end = s1, tileMode = TileMode.Mirror,
            ),
            alpha = alphas[k],
        )

        // Fines fibres à l'intérieur du ruban (effet tissu / fumée)
        for (f in 0..6) {
            val frac = -0.42f + 0.14f * f
            val fp = Path()
            for (i in 0..n) {
                val px = cx[i] + nx * wd[i] * frac
                val py = cy[i] + ny * wd[i] * frac
                if (i == 0) fp.moveTo(px, py) else fp.lineTo(px, py)
            }
            drawPath(fp, Color(0x30FFF6E4), style = Stroke(width = 1.2f * density))
        }
    }
}

/** Paillettes blanches et dorées qui dérivent lentement dans le sens des vagues. */
private fun DrawScope.drawParticles(ps: List<FloatArray>, phase: Float, drift: Float) {
    val w = size.width
    val h = size.height
    for (q in ps) {
        val shift = drift * q[4]
        val x = (q[0] + shift) % 1f
        var y = (q[1] - shift) % 1f
        if (y < 0f) y += 1f
        val edge = minOf(minOf(x, 1f - x), minOf(y, 1f - y))
        val fade = (edge / 0.08f).coerceIn(0f, 1f)
        val a = (0.15f + 0.65f * (0.5f + 0.5f * sin(phase * q[4] * 2f + q[3]))) * fade
        val c = Offset(w * x, h * y)
        val r = q[2] * density
        drawCircle(Color(0xFFFFF4D6).copy(alpha = a), radius = r, center = c)
        if (q[2] > 1.9f) {
            drawCircle(Color(0xFFFFE8B0).copy(alpha = a * 0.25f), radius = r * 3f, center = c)
        }
    }
}

// ------------------------------------------------------------------ Barre du haut (HUD)

@Composable
fun HudBox(clockText: String, battery: Int, charging: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp)
    Row(
        modifier
            .clip(shape)
            .background(Color(0x26FFFFFF))
            .border(1.dp, Color(0x66FFFFFF), shape)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AvatarIcon()
        Spacer(Modifier.width(14.dp))
        Text(clockText, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.width(16.dp))
        BatteryIcon(battery, charging)
        Spacer(Modifier.width(6.dp))
        Text("$battery%", color = Color.White, fontSize = 20.sp)
    }
}

// ------------------------------------------------------------------ Catégories

@Composable
fun CatIcon(
    kind: CatKind,
    label: String,
    selected: Boolean,
    centerX: Dp,
    y: Dp,
    iconSize: Dp,
    onClick: () -> Unit,
) {
    val x by animateDpAsState(centerX, label = "cx")
    val scale by animateFloatAsState(if (selected) 1.3f else 0.9f, label = "cs")
    val glyphAlpha by animateFloatAsState(if (selected) 1f else 0.6f, label = "ca")
    val labelAlpha by animateFloatAsState(if (selected) 1f else 0f, label = "cl")
    Column(
        Modifier.offset(x = x - 65.dp, y = y).width(130.dp).tap(onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CatGlyph(
            kind, iconSize,
            Modifier.graphicsLayer { scaleX = scale; scaleY = scale; alpha = glyphAlpha },
        )
        Text(
            label, fontSize = 14.sp, color = Color.White, maxLines = 1,
            modifier = Modifier.padding(top = iconSize * 0.3f + 4.dp)
                .graphicsLayer { alpha = labelAlpha },
        )
    }
}

// ------------------------------------------------------------------ Lignes de la liste

@Composable
fun XmbRow(
    item: XmbItem,
    selected: Boolean,
    below: Boolean,        // false pour les éléments au-dessus de la sélection (ils disparaissent)
    anchorX: Dp,
    top: Dp,
    rowWidth: Dp,
    onClick: () -> Unit,
) {
    val y by animateDpAsState(top, label = "top")
    val iw by animateDpAsState(if (selected) 132.dp else 64.dp, label = "iw")
    val rowAlpha by animateFloatAsState(
        if (!below) 0f else if (selected) 1f else 0.8f, label = "ra"
    )
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(260)) }

    Row(
        Modifier
            .offset(x = anchorX - 75.dp, y = y)
            .width(rowWidth)
            .graphicsLayer { alpha = rowAlpha * appear.value }
            .tap(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(150.dp).height(80.dp), contentAlignment = Alignment.Center) {
            val frame = Modifier.width(iw).height(iw * (80f / 144f)).clip(RoundedCornerShape(5.dp))
            if (item.icon != null) {
                Box(frame.background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                    AsyncImage(
                        model = item.icon, contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else if (item.kind != null) {
                CatGlyph(item.kind, iw * 0.45f)
            } else {
                Box(frame.background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
                    Text(
                        item.title.take(2).uppercase(), color = Color.White,
                        fontSize = if (selected) 26.sp else 18.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(
                item.title, color = Color.White,
                fontSize = if (selected) 22.sp else 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (selected) {
                Text(
                    item.subtitle, color = Color(0xE6FFFFFF), fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (selected && item.badge != null) {
            Box(
                Modifier.clip(RoundedCornerShape(3.dp))
                    .background(Color(0xCCB8B8B8))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                Text(item.badge, fontSize = 11.sp, color = Color(0xFF3A2A12), fontWeight = FontWeight.Bold)
            }
        }
    }
}

package com.you.pspl.launch

import android.content.Context

/** Derniers jeux lancés (uri + date), les plus récents en premier. */
object Recents {
    private const val KEY = "recent"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Pair<String, Long>> =
        (prefs(ctx).getString(KEY, "") ?: "").lines().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toLongOrNull()?.let { p[0] to it } else null
        }

    fun add(ctx: Context, uri: String) {
        val list = (listOf(uri to System.currentTimeMillis()) + load(ctx).filter { it.first != uri })
            .take(10)
        prefs(ctx).edit()
            .putString(KEY, list.joinToString("\n") { it.first + "\t" + it.second })
            .apply()
    }
}

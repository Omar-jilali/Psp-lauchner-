package com.you.pspl.ui

/** Commandes de navigation (manette ou clavier), envoyées par MainActivity. */
enum class Nav { LEFT, RIGHT, UP, DOWN, SELECT, BACK, OPTIONS }

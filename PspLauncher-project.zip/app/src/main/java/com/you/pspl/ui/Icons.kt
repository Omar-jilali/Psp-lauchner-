package com.you.pspl.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class CatKind { FILM, FOLDER, GAMEPAD, GLOBE, PSN, FRIENDS }

private val ICON = Color(0xFFEDE7DC)   // gris clair
private val CUT = Color(0xFF7A4C1A)    // brun (simule un "trou" dans l'icône)

@Composable
fun CatGlyph(kind: CatKind, boxSize: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(boxSize)) {
        val s = this.size.minDimension
        when (kind) {
            CatKind.FILM -> drawFilm(s)
            CatKind.FOLDER -> drawFolder(s)
            CatKind.GAMEPAD -> drawGamepad(s)
            CatKind.GLOBE -> drawGlobe(s)
            CatKind.PSN -> drawPsn(s)
            CatKind.FRIENDS -> drawFriends(s)
        }
    }
}

private fun DrawScope.drawFilm(s: Float) {
    val sw = s * 0.06f
    drawRoundRect(
        ICON, Offset(s * 0.08f, s * 0.22f), Size(s * 0.84f, s * 0.56f),
        CornerRadius(s * 0.06f), style = Stroke(sw),
    )
    for (i in 0 until 4) {
        val y = s * (0.28f + i * 0.125f)
        drawRect(ICON, Offset(s * 0.14f, y), Size(s * 0.07f, s * 0.07f))
        drawRect(ICON, Offset(s * 0.79f, y), Size(s * 0.07f, s * 0.07f))
    }
    drawRect(ICON, Offset(s * 0.30f, s * 0.30f), Size(s * 0.40f, s * 0.40f), style = Stroke(sw * 0.8f))
}

private fun DrawScope.drawFolder(s: Float) {
    val p = Path().apply {
        moveTo(s * 0.10f, s * 0.28f)
        lineTo(s * 0.40f, s * 0.28f)
        lineTo(s * 0.48f, s * 0.36f)
        lineTo(s * 0.90f, s * 0.36f)
        lineTo(s * 0.90f, s * 0.78f)
        lineTo(s * 0.10f, s * 0.78f)
        close()
    }
    drawPath(p, ICON)
    drawRoundRect(CUT, Offset(s * 0.32f, s * 0.48f), Size(s * 0.36f, s * 0.18f), CornerRadius(s * 0.07f))
    drawRect(ICON, Offset(s * 0.36f, s * 0.545f), Size(s * 0.10f, s * 0.03f))
    drawRect(ICON, Offset(s * 0.395f, s * 0.515f), Size(s * 0.03f, s * 0.09f))
    drawCircle(ICON, s * 0.025f, Offset(s * 0.58f, s * 0.54f))
    drawCircle(ICON, s * 0.025f, Offset(s * 0.62f, s * 0.585f))
}

private fun DrawScope.drawGamepad(s: Float) {
    drawRoundRect(ICON, Offset(s * 0.14f, s * 0.30f), Size(s * 0.72f, s * 0.30f), CornerRadius(s * 0.14f))
    drawCircle(ICON, s * 0.15f, Offset(s * 0.26f, s * 0.60f))
    drawCircle(ICON, s * 0.15f, Offset(s * 0.74f, s * 0.60f))
    // croix directionnelle
    drawRect(CUT, Offset(s * 0.25f, s * 0.425f), Size(s * 0.16f, s * 0.045f))
    drawRect(CUT, Offset(s * 0.305f, s * 0.37f), Size(s * 0.045f, s * 0.16f))
    // boutons
    drawCircle(CUT, s * 0.032f, Offset(s * 0.68f, s * 0.39f))
    drawCircle(CUT, s * 0.032f, Offset(s * 0.68f, s * 0.51f))
    drawCircle(CUT, s * 0.032f, Offset(s * 0.62f, s * 0.45f))
    drawCircle(CUT, s * 0.032f, Offset(s * 0.74f, s * 0.45f))
}

private fun DrawScope.drawGlobe(s: Float) {
    val c = Offset(s / 2f, s / 2f)
    val r = s * 0.34f
    val st = Stroke(s * 0.05f)
    drawCircle(ICON, r, c, style = st)
    drawOval(ICON, Offset(c.x - r * 0.45f, c.y - r), Size(r * 0.9f, r * 2f), style = st)
    drawLine(ICON, Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = s * 0.045f)
    drawLine(ICON, Offset(c.x - r * 0.86f, c.y - r * 0.5f), Offset(c.x + r * 0.86f, c.y - r * 0.5f), strokeWidth = s * 0.04f)
    drawLine(ICON, Offset(c.x - r * 0.86f, c.y + r * 0.5f), Offset(c.x + r * 0.86f, c.y + r * 0.5f), strokeWidth = s * 0.04f)
}

private fun DrawScope.drawPsn(s: Float) {
    val c = Offset(s / 2f, s / 2f)
    drawCircle(
        Brush.radialGradient(listOf(Color(0xFF9A5BDB), Color(0xFF4A1C93)), center = c, radius = s * 0.5f),
        radius = s * 0.46f, center = c,
    )
    for (i in 0 until 3) {
        drawRoundRect(
            Color.White, Offset(s * 0.26f, s * (0.33f + i * 0.13f)),
            Size(s * 0.40f, s * 0.075f), CornerRadius(s * 0.04f),
        )
    }
    drawRoundRect(Color.White, Offset(s * 0.60f, s * 0.33f), Size(s * 0.075f, s * 0.275f), CornerRadius(s * 0.04f))
}

private fun DrawScope.drawFriends(s: Float) {
    fun face(x: Float, y: Float, w: Float) {
        drawRoundRect(ICON, Offset(x, y), Size(w, w), CornerRadius(w * 0.28f))
        drawCircle(CUT, w * 0.07f, Offset(x + w * 0.32f, y + w * 0.40f))
        drawCircle(CUT, w * 0.07f, Offset(x + w * 0.68f, y + w * 0.40f))
        drawArc(
            CUT, 20f, 140f, false, Offset(x + w * 0.28f, y + w * 0.45f),
            Size(w * 0.44f, w * 0.32f), style = Stroke(w * 0.07f),
        )
    }
    face(s * 0.14f, s * 0.40f, s * 0.34f)
    face(s * 0.50f, s * 0.24f, s * 0.34f)
}

/** Petit avatar carré avec visage souriant (en haut à droite). */
@Composable
fun AvatarIcon() {
    Canvas(Modifier.size(26.dp)) {
        val s = this.size.minDimension
        drawRoundRect(ICON, Offset.Zero, Size(s, s), CornerRadius(s * 0.2f), style = Stroke(s * 0.07f))
        drawRoundRect(
            ICON.copy(alpha = 0.85f), Offset(s * 0.14f, s * 0.14f),
            Size(s * 0.72f, s * 0.72f), CornerRadius(s * 0.14f),
        )
        drawCircle(CUT, s * 0.055f, Offset(s * 0.37f, s * 0.43f))
        drawCircle(CUT, s * 0.055f, Offset(s * 0.63f, s * 0.43f))
        drawArc(
            CUT, 20f, 140f, false, Offset(s * 0.31f, s * 0.46f),
            Size(s * 0.38f, s * 0.26f), style = Stroke(s * 0.06f),
        )
    }
}

/** Batterie horizontale, avec éclair quand elle charge. */
@Composable
fun BatteryIcon(pct: Int, charging: Boolean) {
    Canvas(Modifier.size(width = 34.dp, height = 17.dp)) {
        val w = this.size.width
        val h = this.size.height
        val bodyW = w * 0.90f
        drawRoundRect(ICON, Offset.Zero, Size(bodyW, h), CornerRadius(h * 0.2f), style = Stroke(h * 0.10f))
        val inner = (bodyW - h * 0.3f) * (pct.coerceIn(0, 100) / 100f)
        drawRoundRect(ICON, Offset(h * 0.15f, h * 0.15f), Size(inner, h * 0.70f), CornerRadius(h * 0.1f))
        drawRoundRect(ICON, Offset(bodyW, h * 0.3f), Size(w - bodyW, h * 0.4f), CornerRadius(h * 0.1f))
        if (charging) {
            val bolt = Path().apply {
                moveTo(bodyW * 0.55f, h * 0.06f)
                lineTo(bodyW * 0.35f, h * 0.55f)
                lineTo(bodyW * 0.50f, h * 0.55f)
                lineTo(bodyW * 0.42f, h * 0.94f)
                lineTo(bodyW * 0.68f, h * 0.42f)
                lineTo(bodyW * 0.52f, h * 0.42f)
                close()
            }
            drawPath(bolt, CUT)
        }
    }
}

package com.you.pspl.player

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/** Android ne lit pas l'ATRAC3+ : on convertit SND0.AT3 en .m4a une seule fois. */
object MusicConverter {
    fun ensure(raw: File?): File? {
        if (raw == null || !raw.exists()) return null
        val out = File(raw.parentFile, "bgm.m4a")
        if (out.exists() && out.length() > 0) return out
        val session = FFmpegKit.execute(
            "-y -i \"${raw.absolutePath}\" -vn -c:a aac -b:a 128k \"${out.absolutePath}\""
        )
        return if (ReturnCode.isSuccess(session.returnCode) && out.length() > 0) out
        else { out.delete(); null }
    }
}

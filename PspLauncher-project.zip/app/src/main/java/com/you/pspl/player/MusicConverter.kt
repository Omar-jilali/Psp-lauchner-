package com.you.pspl.player

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Android ne lit pas l'ATRAC3+ : on convertit SND0.AT3 en .m4a une seule fois (cache). */
object MusicConverter {
    private val lock = Mutex()   // une conversion à la fois

    suspend fun ensure(raw: File?): File? {
        if (raw == null || !raw.exists()) return null
        val out = File(raw.parentFile, "bgm.m4a")
        if (out.exists() && out.length() > 0) return out
        return lock.withLock {
            if (out.exists() && out.length() > 0) return@withLock out
            val tmp = File(raw.parentFile, "bgm.tmp.m4a").apply { delete() }
            val ok = convert(raw, tmp)
            if (ok && tmp.length() > 0 && tmp.renameTo(out)) out else { tmp.delete(); null }
        }
    }

    /** Annulable : si l'utilisateur change de jeu, ffmpeg est stoppé. */
    private suspend fun convert(src: File, dst: File): Boolean = suspendCancellableCoroutine { cont ->
        val session = FFmpegKit.executeAsync(
            "-y -i \"${src.absolutePath}\" -vn -c:a aac -b:a 128k \"${dst.absolutePath}\""
        ) { s ->
            val ok = ReturnCode.isSuccess(s.returnCode)
            if (!ok && !ReturnCode.isCancel(s.returnCode)) {
                Log.w("MusicConverter", "ffmpeg a échoué sur ${src.name} : ${s.logsAsString}")
            }
            if (cont.isActive) cont.resume(ok)
        }
        cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
    }
}

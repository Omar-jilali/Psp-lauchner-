package com.you.pspl.player

import android.media.MediaPlayer
import java.io.File

/** Lit un fichier audio supporté par Android (ogg/mp3/wav).
 *  SND0.AT3 (ATRAC3+) doit d'abord être converti : étape à ajouter. */
object Bgm {
    private var mp: MediaPlayer? = null
    fun play(f: File?) {
        stop()
        if (f == null || !f.exists() || f.extension.lowercase() == "at3") return
        mp = MediaPlayer().apply {
            setDataSource(f.absolutePath); isLooping = true
            prepare(); start()
        }
    }
    fun stop() { mp?.release(); mp = null }
}

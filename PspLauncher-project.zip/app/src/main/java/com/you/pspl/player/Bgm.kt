package com.you.pspl.player

import android.media.MediaPlayer
import java.io.File

/** Musique de fond. stop() libère le lecteur mais retient la piste pour resume(). */
object Bgm {
    private var mp: MediaPlayer? = null
    private var last: File? = null

    fun play(f: File?) {
        last = f
        release()
        if (f == null || !f.exists()) return
        start(f)
    }

    /** À appeler quand l'app revient au premier plan (ex. retour de PPSSPP). */
    fun resume() { if (mp == null) last?.takeIf { it.exists() }?.let { start(it) } }

    fun stop() = release()

    private fun start(f: File) {
        runCatching {
            mp = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                isLooping = true
                setVolume(0.8f, 0.8f)
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        }.onFailure { release() }
    }

    private fun release() { runCatching { mp?.release() }; mp = null }
}

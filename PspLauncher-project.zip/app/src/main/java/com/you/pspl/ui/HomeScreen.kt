package com.you.pspl.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.launch.*
import com.you.pspl.player.Bgm
import com.you.pspl.player.MusicConverter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

enum class Nav { LEFT, RIGHT, UP, DOWN, SELECT, BACK, OPTIONS }

private const val CUSTOM = "custom_bg"

private class Choice(val label: String, val action: () -> Unit)

private fun clock(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

private fun customFiles(g: Game): List<File> =
    g.dir.listFiles { f -> f.name.startsWith(CUSTOM) }?.toList() ?: emptyList()

@Composable
fun HomeScreen(games: List<Game>, nav: Flow<Nav>) {
    val ctx = LocalContext.current
    val gamesNow by rememberUpdatedState(games)
    var index by remember { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }
    var menuIndex by remember { mutableIntStateOf(0) }
    var time by remember { mutableStateOf(clock()) }
    val listState = rememberLazyListState()

    // Émulateur : choix mémorisé + sélecteur (0 = fermé, 1 = avant de jouer, 2 = réglage)
    var savedPkg by remember { mutableStateOf(loadSavedPkg(ctx)) }
    var emuMode by remember { mutableIntStateOf(0) }
    var emuIndex by remember { mutableIntStateOf(0) }
    var emuList by remember { mutableStateOf(listOf<Emu>()) }
    var rememberChoice by remember { mutableStateOf(true) }
    val savedEmu = KNOWN_EMUS.firstOrNull { it.pkg == savedPkg && isInstalled(ctx, it) }

    // Fonds personnalisés (un par jeu)
    val customBg = remember {
        mutableStateMapOf<String, File>().also { m ->
            games.forEach { g -> customFiles(g).firstOrNull()?.let { m[g.discId] = it } }
        }
    }
    fun bgOf(g: Game?): File? = g?.let { customBg[it.discId] ?: it.background }

    val selected = games.getOrNull(index)

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val g = gamesNow.getOrNull(index)
        if (uri != null && g != null) {
            runCatching {
                customFiles(g).forEach { it.delete() }
                val out = File(g.dir, "${CUSTOM}_${System.currentTimeMillis()}.img")
                ctx.contentResolver.openInputStream(uri)?.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                customBg[g.discId] = out
            }
        }
        showMenu = false
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun openEmuPicker(mode: Int) {
        emuList = installedEmus(ctx)
        emuMode = mode
        emuIndex = 0
        rememberChoice = true
        showMenu = false
    }

    fun chooseEmu(e: Emu) {
        val g = gamesNow.getOrNull(index)
        if (emuMode == 1) {
            if (rememberChoice) { savedPkg = e.pkg; storeSavedPkg(ctx, e.pkg) }
            emuMode = 0
            if (g != null && !launchWith(ctx, e, g.isoUri)) toast("Impossible de lancer ${e.name}")
        } else {
            savedPkg = e.pkg; storeSavedPkg(ctx, e.pkg)
            emuMode = 0
        }
    }

    fun play() {
        val g = gamesNow.getOrNull(index) ?: return
        val e = savedEmu
        if (e == null) openEmuPicker(1)
        else if (!launchWith(ctx, e, g.isoUri)) toast("Impossible de lancer ${e.name}")
    }

    fun move(d: Int) {
        val n = gamesNow.size
        if (n > 0) index = (index + d).coerceIn(0, n - 1)
    }

    fun menuAction(i: Int) {
        when (i) {
            0 -> imagePicker.launch(arrayOf("image/*"))
            1 -> {
                gamesNow.getOrNull(index)?.let { g ->
                    customFiles(g).forEach { it.delete() }
                    customBg.remove(g.discId)
                }
                showMenu = false
            }
            2 -> openEmuPicker(2)
            else -> showMenu = false
        }
    }

    val menuLabels = listOf(
        "🖼  Changer l'image de fond",
        "↩  Revenir au fond d'origine",
        "🎮  Émulateur : ${savedEmu?.name ?: "demander à chaque fois"}",
        "Fermer",
    )

    val emuRows: List<Choice> = buildList {
        emuList.forEach { e ->
            val mark = if (emuMode == 2 && e.pkg == savedPkg) "✓  " else ""
            add(Choice(mark + e.name) { chooseEmu(e) })
        }
        if (emuMode == 1) {
            add(Choice("📂  Autre application…") {
                emuMode = 0
                gamesNow.getOrNull(index)?.let {
                    if (!launchChooser(ctx, it.isoUri)) toast("Aucune application trouvée")
                }
            })
            add(Choice((if (rememberChoice) "☑" else "☐") + "  Se souvenir de mon choix") {
                rememberChoice = !rememberChoice
            })
        } else {
            add(Choice("↺  Toujours demander") {
                savedPkg = null; storeSavedPkg(ctx, null); emuMode = 0
            })
        }
    }

    // Événements manette (voir MainActivity)
    val onNav by rememberUpdatedState<(Nav) -> Unit>({ n ->
        if (emuMode != 0) {
            when (n) {
                Nav.UP -> emuIndex = (emuIndex - 1).coerceAtLeast(0)
                Nav.DOWN -> emuIndex = (emuIndex + 1).coerceAtMost(emuRows.size - 1)
                Nav.SELECT -> emuRows.getOrNull(emuIndex)?.action?.invoke()
                Nav.BACK, Nav.OPTIONS -> emuMode = 0
                else -> {}
            }
        } else if (showMenu) {
            when (n) {
                Nav.UP -> menuIndex = (menuIndex - 1).coerceAtLeast(0)
                Nav.DOWN -> menuIndex = (menuIndex + 1).coerceAtMost(menuLabels.size - 1)
                Nav.SELECT -> menuAction(menuIndex)
                Nav.BACK, Nav.OPTIONS -> showMenu = false
                else -> {}
            }
        } else {
            when (n) {
                Nav.LEFT -> move(-1)
                Nav.RIGHT -> move(1)
                Nav.SELECT -> play()
                Nav.OPTIONS -> { menuIndex = 0; showMenu = true }
                else -> {}
            }
        }
    })
    LaunchedEffect(Unit) { nav.collect { onNav(it) } }

    LaunchedEffect(Unit) { while (true) { time = clock(); delay(15_000) } }
    LaunchedEffect(index) { listState.animateScrollToItem((index - 1).coerceAtLeast(0)) }

    // Musique de fond du jeu sélectionné
    LaunchedEffect(index, games) {
        val g = games.getOrNull(index)
        delay(350)
        val f = withContext(Dispatchers.IO) {
            runCatching { MusicConverter.ensure(g?.music) }.getOrNull()
        }
        Bgm.play(f)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Crossfade(targetState = bgOf(selected), label = "bg") { bg ->
            AsyncImage(
                model = bg, contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xCC000000), Color(0x22000000), Color(0xF0000000))
                )
            )
        )

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Games", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(time, color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp))

            LazyRow(
                state = listState,
                modifier = Modifier.height(112.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(games) { i, g ->
                    val isSel = i == index
                    val h by animateDpAsState(if (isSel) 80.dp else 52.dp, label = "h")
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AsyncImage(
                            model = g.icon, contentDescription = g.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .height(h).aspectRatio(144f / 80f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    if (isSel) 2.dp else 0.dp,
                                    if (isSel) Color.White else Color.Transparent,
                                    RoundedCornerShape(12.dp),
                                )
                                .clickable { index = i },
                        )
                        if (isSel) {
                            Text(
                                g.title, color = Color.White, fontSize = 11.sp,
                                maxLines = 1,
                                modifier = Modifier.widthIn(max = 150.dp).padding(top = 4.dp),
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            selected?.let { g ->
                Text(
                    g.title, color = Color.White, fontSize = 30.sp,
                    fontWeight = FontWeight.Bold, maxLines = 2,
                )
                Text(g.discId, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { play() },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White, contentColor = Color.Black),
                    ) { Text("▶  Jouer", fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(12.dp))
                    Box(
                        Modifier.size(44.dp).clip(CircleShape)
                            .background(Color(0x66FFFFFF))
                            .clickable { menuIndex = 0; showMenu = true },
                        contentAlignment = Alignment.Center,
                    ) { Text("⚙", color = Color.White, fontSize = 22.sp) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "✕ Jouer     △ Options     ◀ ▶ Naviguer",
                color = Color(0x99FFFFFF), fontSize = 12.sp,
            )
        }

        if (emuMode != 0) {
            OptionsPanel(
                title = if (emuMode == 1) "Lancer avec…" else "Émulateur par défaut",
                labels = emuRows.map { it.label },
                selected = emuIndex,
                onPick = { emuIndex = it; emuRows.getOrNull(it)?.action?.invoke() },
                onDismiss = { emuMode = 0 },
            )
        } else if (showMenu && selected != null) {
            OptionsPanel(
                title = "Options : ${selected.title}",
                labels = menuLabels,
                selected = menuIndex,
                onPick = { menuIndex = it; menuAction(it) },
                onDismiss = { showMenu = false },
            )
        }
    }
}

@Composable
private fun OptionsPanel(
    title: String,
    labels: List<String>,
    selected: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    Box(
        Modifier.fillMaxSize().background(Color(0xAA000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.widthIn(max = 420.dp).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xF01C1C1E))
                .clickable(onClick = {})
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                title, color = Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.Bold, maxLines = 1,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            labels.forEachIndexed { i, label ->
                val on = selected == i
                Text(
                    label,
                    color = if (on) Color.Black else Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (on) Color.White else Color.Transparent)
                        .clickable { onPick(i) }
                        .padding(12.dp),
                )
            }
        }
    }
}

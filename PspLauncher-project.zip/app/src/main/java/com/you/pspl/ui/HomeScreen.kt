package com.you.pspl.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.InputDevice
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.data.GameScanner
import com.you.pspl.data.Img
import com.you.pspl.launch.Emu
import com.you.pspl.launch.Emulators
import com.you.pspl.launch.Recents
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow

private class PanelRow(
    val label: String,
    val enabled: Boolean = true,
    val onClick: () -> Unit = {},
)

private const val R_RECENT = 0
private const val R_EMU = 1
private const val R_PLATFORM = 2
private const val R_LIB = 3
private const val R_SETTINGS = 4
private const val R_ABOUT = 5

private class Cat(val kind: CatKind, val label: String, val role: Int, val platform: String? = null)

private fun clock(): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())

private fun fmtDate(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(t))

private fun batteryInfo(ctx: Context): Pair<Int, Boolean> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        ?: return 100 to false
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
    return pct to charging
}

private fun findPad(): String? =
    InputDevice.getDeviceIds().asSequence()
        .mapNotNull { InputDevice.getDevice(it) }
        .firstOrNull {
            (it.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (it.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        }?.name

@Composable
fun HomeScreen(
    games: List<Game>,
    errors: List<String>,
    nav: Flow<Nav>,
    onChangeFolder: () -> Unit,
    onRefresh: () -> Unit,
) {
    val ctx = LocalContext.current

    // ---- Catégories : une par console trouvée (d'après les sous-dossiers)
    val platforms = remember(games) { GameScanner.sortPlatforms(games.map { it.platform }.distinct()) }
    val cats = remember(platforms) {
        buildList<Cat> {
            add(Cat(CatKind.FILM, "Récents", R_RECENT))
            add(Cat(CatKind.FOLDER, "Émulateur", R_EMU))
            platforms.forEach { add(Cat(CatKind.GAMEPAD, it, R_PLATFORM, it)) }
            add(Cat(CatKind.GLOBE, "Bibliothèque", R_LIB))
            add(Cat(CatKind.PSN, "Paramètres", R_SETTINGS))
            add(Cat(CatKind.FRIENDS, "À propos", R_ABOUT))
        }
    }
    var cat by remember { mutableIntStateOf(2) }                  // 2 = première console
    val sels = remember(cats.size) {
        mutableStateListOf<Int>().also { l -> repeat(cats.size) { l.add(0) } }
    }

    var emuList by remember { mutableStateOf(Emulators.installed(ctx)) }
    val saved = remember {
        mutableStateMapOf<String, String>().also { m ->
            platforms.forEach { p -> Emulators.savedPkg(ctx, p)?.let { m[p] = it } }
        }
    }
    var picker by remember { mutableIntStateOf(0) }               // 0 fermé, 1 lancer avec, 2 défaut
    var pickerPlatform by remember { mutableStateOf("") }
    var pendingGame by remember { mutableStateOf<Game?>(null) }
    var rememberChoice by remember { mutableStateOf(true) }
    var showOptions by remember { mutableStateOf(false) }
    var showErrors by remember { mutableStateOf(false) }
    var panelIdx by remember { mutableIntStateOf(0) }
    var clockText by remember { mutableStateOf(clock()) }
    var battery by remember { mutableStateOf(batteryInfo(ctx)) }
    var recents by remember { mutableStateOf(Recents.load(ctx)) }
    var padName by remember { mutableStateOf(findPad()) }

    // ---- Images personnalisées (logo = icône, arrière-plan)
    val customIcon = remember {
        mutableStateMapOf<String, Img>().also { m ->
            games.forEach { g -> GameScanner.customImg(g.dir, "custom_icon")?.let { m[g.key] = it } }
        }
    }
    val customBg = remember {
        mutableStateMapOf<String, Img>().also { m ->
            games.forEach { g -> GameScanner.customImg(g.dir, "custom_bg")?.let { m[g.key] = it } }
        }
    }
    var pickTarget by remember { mutableIntStateOf(0) }           // 1 = logo, 2 = arrière-plan
    var pickGame by remember { mutableStateOf<Game?>(null) }

    val overlayOpen = picker != 0 || showOptions || showErrors

    LaunchedEffect(cat, picker) { emuList = Emulators.installed(ctx) }
    LaunchedEffect(Unit) {
        while (true) {
            clockText = clock()
            battery = batteryInfo(ctx)
            padName = findPad()
            delay(20_000)
        }
    }

    BackHandler(enabled = overlayOpen) {
        when {
            picker != 0 -> picker = 0
            showOptions -> showOptions = false
            else -> showErrors = false
        }
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun iconImg(g: Game): Img? = customIcon[g.key] ?: g.icon?.let { Img(it, g.iconAspect) }
    fun bgFile(g: Game?): File? = g?.let { customBg[it.key]?.file ?: it.background }
    fun savedEmuFor(platform: String): Emu? = emuList.firstOrNull { it.pkg == saved[platform] }

    fun setSaved(platform: String, pkg: String?) {
        if (pkg == null) saved.remove(platform) else saved[platform] = pkg
        Emulators.save(ctx, platform, pkg)
    }

    fun resetImages(g: Game) {
        g.dir.listFiles { f -> f.name.startsWith("custom_") }?.forEach { it.delete() }
        customIcon.remove(g.key)
        customBg.remove(g.key)
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val g = pickGame
        if (uri != null && g != null) {
            val ok = runCatching {
                val prefix = if (pickTarget == 1) "custom_icon" else "custom_bg"
                g.dir.listFiles { f -> f.name.startsWith(prefix) }?.forEach { it.delete() }
                val out = File(g.dir, prefix + "_" + System.currentTimeMillis() + ".img")
                ctx.contentResolver.openInputStream(uri)?.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                val img = Img(out, GameScanner.imageAspect(out))
                if (pickTarget == 1) customIcon[g.key] = img else customBg[g.key] = img
            }.isSuccess
            if (!ok) toast("Impossible d'utiliser cette image")
        }
    }

    fun openPicker(mode: Int, platform: String, keep: Boolean) {
        emuList = Emulators.installed(ctx)
        pickerPlatform = platform
        rememberChoice = keep
        panelIdx = 0
        picker = mode
    }

    fun launchWith(e: Emu, g: Game) {
        if (Emulators.launch(ctx, e, g.isoUri)) {
            Recents.add(ctx, g.isoUri.toString())
            recents = Recents.load(ctx)
        } else {
            toast("Impossible de lancer ${e.name}")
        }
    }

    fun play(g: Game) {
        emuList = Emulators.installed(ctx)
        val e = savedEmuFor(g.platform)
        if (e != null) launchWith(e, g) else { pendingGame = g; openPicker(1, g.platform, true) }
    }

    fun choose(e: Emu) {
        if (picker == 1) {
            if (rememberChoice) setSaved(pickerPlatform, e.pkg)
            picker = 0
            pendingGame?.let { launchWith(e, it) }
        } else {
            setSaved(pickerPlatform, e.pkg)
            picker = 0
        }
    }

    fun closeTop() {
        when {
            picker != 0 -> picker = 0
            showOptions -> showOptions = false
            else -> showErrors = false
        }
    }

    // ---- Contenu de la liste verticale selon la catégorie
    val c = cats[cat.coerceIn(0, cats.size - 1)]
    val platformGames: List<Game> =
        if (c.role == R_PLATFORM) games.filter { it.platform == c.platform } else emptyList()

    val items: List<XmbItem> = when (c.role) {
        R_RECENT -> {
            val list = recents.mapNotNull { (u, t) ->
                games.firstOrNull { it.isoUri.toString() == u }?.let { g ->
                    XmbItem(iconImg(g), null, g.title, fmtDate(t), g.badge) { play(g) }
                }
            }
            list.ifEmpty {
                listOf(XmbItem(null, CatKind.FILM, "Aucun jeu lancé récemment",
                    "Les jeux que tu lances apparaîtront ici", null) {})
            }
        }
        R_EMU -> buildList {
            platforms.forEach { p ->
                add(XmbItem(null, CatKind.GAMEPAD, "Émulateur $p",
                    savedEmuFor(p)?.name ?: "Demander à chaque fois", null) { openPicker(2, p, true) })
            }
            emuList.forEach { e ->
                add(XmbItem(null, CatKind.FOLDER, e.name,
                    "Installé" + if (e.platforms.isNotEmpty()) " · " + e.platforms.joinToString(", ") else "",
                    null) {})
            }
            if (emuList.isEmpty()) {
                add(XmbItem(null, CatKind.FOLDER, "Aucun émulateur détecté",
                    "Installe PPSSPP ou un autre émulateur", null) {})
            }
        }
        R_PLATFORM -> platformGames.map { g ->
            XmbItem(iconImg(g), null, g.title, g.discId.ifEmpty { "Image ISO" }, g.badge) { play(g) }
        }
        R_LIB -> buildList {
            add(XmbItem(null, CatKind.FOLDER, "Dossier des jeux",
                "Changer le dossier contenant les ISO", null) { onChangeFolder() })
            add(XmbItem(null, CatKind.GLOBE, "Actualiser la bibliothèque",
                "Relire les jeux et leurs images", null) { onRefresh() })
            add(XmbItem(null, CatKind.FILM, "Consoles détectées",
                platforms.joinToString(" · ") { p -> p + " (" + games.count { it.platform == p } + ")" },
                null) {})
            if (errors.isNotEmpty()) {
                add(XmbItem(null, CatKind.FILM, "Problèmes détectés",
                    "${errors.size} fichier(s) en erreur", null) { panelIdx = 0; showErrors = true })
            }
        }
        R_SETTINGS -> listOf(
            XmbItem(null, CatKind.GAMEPAD, "Manette",
                padName?.let { "Connectée : $it" } ?: "Aucune manette détectée", null) {},
            XmbItem(null, CatKind.GLOBE, "Réinitialiser les émulateurs choisis",
                "Redemander l'émulateur pour chaque console", null) {
                platforms.forEach { setSaved(it, null) }
            },
            XmbItem(null, CatKind.FILM, "Réinitialiser toutes les images",
                "Supprimer les logos et arrière-plans personnalisés", null) {
                games.forEach { resetImages(it) }
            },
        )
        else -> listOf(
            XmbItem(null, CatKind.PSN, "PSP Launcher", "Version 3.0", null) {},
            XmbItem(null, CatKind.FOLDER, "Bibliothèque", "${games.size} jeu(x) trouvé(s)", null) {},
        )
    }
    val sel = sels[cat].coerceIn(0, (items.size - 1).coerceAtLeast(0))
    val game: Game? = platformGames.getOrNull(sel)

    fun moveCat(d: Int) { if (!overlayOpen) cat = (cat + d).coerceIn(0, cats.size - 1) }
    fun moveItem(d: Int) {
        if (!overlayOpen) sels[cat] = (sel + d).coerceIn(0, (items.size - 1).coerceAtLeast(0))
    }

    // ---- Fenêtres : choix d'émulateur, options du jeu, problèmes
    val pickerRows: List<PanelRow> = buildList {
        val ordered = emuList.sortedByDescending { pickerPlatform in it.platforms }
        if (ordered.isEmpty()) add(PanelRow("Aucun émulateur connu détecté", enabled = false))
        ordered.forEach { e ->
            val star = if (pickerPlatform in e.platforms) "★  " else ""
            val mark = if (picker == 2 && e.pkg == saved[pickerPlatform]) "✓  " else ""
            add(PanelRow(mark + star + e.name) { choose(e) })
        }
        if (picker == 1) {
            add(PanelRow("📂  Autre application…") {
                picker = 0
                pendingGame?.let {
                    if (!Emulators.chooser(ctx, it.isoUri)) toast("Aucune application trouvée")
                }
            })
            add(PanelRow((if (rememberChoice) "☑" else "☐") + "  Se souvenir de mon choix") {
                rememberChoice = !rememberChoice
            })
            add(PanelRow("Annuler") { picker = 0 })
        } else {
            if (saved[pickerPlatform] != null) {
                add(PanelRow("↺  Toujours demander") { setSaved(pickerPlatform, null); picker = 0 })
            }
            add(PanelRow("Retour") { picker = 0 })
        }
    }

    val optionRows: List<PanelRow> = game?.let { g ->
        listOf(
            PanelRow("▶  Lancer") { showOptions = false; play(g) },
            PanelRow("🎮  Lancer avec un autre émulateur…") {
                showOptions = false
                pendingGame = g
                openPicker(1, g.platform, false)
            },
            PanelRow("⭐  Émulateur par défaut (${g.platform})…") {
                showOptions = false
                openPicker(2, g.platform, true)
            },
            PanelRow("🖼  Changer le logo…") {
                showOptions = false
                pickGame = g; pickTarget = 1
                imagePicker.launch(arrayOf("image/*"))
            },
            PanelRow("🌄  Changer l'arrière-plan…") {
                showOptions = false
                pickGame = g; pickTarget = 2
                imagePicker.launch(arrayOf("image/*"))
            },
            PanelRow(
                "↺  Rétablir les images d'origine",
                enabled = customIcon.containsKey(g.key) || customBg.containsKey(g.key),
            ) { resetImages(g); showOptions = false },
            PanelRow("Fermer") { showOptions = false },
        )
    } ?: emptyList()

    val errorRows: List<PanelRow> =
        errors.take(30).map { PanelRow(it, enabled = false) } + PanelRow("Fermer") { showErrors = false }

    val activeRows: List<PanelRow>? = when {
        picker != 0 -> pickerRows
        showOptions -> optionRows
        showErrors -> errorRows
        else -> null
    }

    // ---- Manette / commandes
    fun handleNav(n: Nav) {
        padName = padName ?: findPad()
        val rows = activeRows
        if (rows != null) {
            when (n) {
                Nav.UP -> panelIdx = (panelIdx - 1).coerceAtLeast(0)
                Nav.DOWN -> panelIdx = (panelIdx + 1).coerceAtMost((rows.size - 1).coerceAtLeast(0))
                Nav.SELECT -> {
                    val r = rows.getOrNull(panelIdx)
                    if (r != null && r.enabled) r.onClick()
                }
                Nav.BACK, Nav.OPTIONS -> closeTop()
                else -> {}
            }
        } else {
            when (n) {
                Nav.LEFT -> moveCat(-1)
                Nav.RIGHT -> moveCat(1)
                Nav.UP -> moveItem(-1)
                Nav.DOWN -> moveItem(1)
                Nav.SELECT -> items.getOrNull(sel)?.onActivate?.invoke()
                Nav.OPTIONS -> if (game != null) { panelIdx = 0; showOptions = true }
                Nav.BACK -> {}
            }
        }
    }
    val onNav by rememberUpdatedState<(Nav) -> Unit>({ n -> handleNav(n) })
    LaunchedEffect(Unit) { nav.collect { onNav(it) } }

    val onMoveCat by rememberUpdatedState<(Int) -> Unit>({ d -> moveCat(d) })
    val onMoveItem by rememberUpdatedState<(Int) -> Unit>({ d -> moveItem(d) })

    BoxWithConstraints(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var dx = 0f
            var dy = 0f
            detectDragGestures(
                onDragStart = { dx = 0f; dy = 0f },
                onDragEnd = {
                    if (abs(dx) > abs(dy)) {
                        if (dx < -70f) onMoveCat(1) else if (dx > 70f) onMoveCat(-1)
                    } else {
                        if (dy < -70f) onMoveItem(1) else if (dy > 70f) onMoveItem(-1)
                    }
                },
                onDrag = { change, amount ->
                    change.consume()
                    dx += amount.x
                    dy += amount.y
                },
            )
        }
    ) {
        val w = maxWidth
        val h = maxHeight
        val anchorX = w * 0.293f          // colonne active (comme sur la PS3)
        val spacing = w * 0.107f
        val iconSize = maxOf(w * 0.05f, 34.dp)
        val catY = h * 0.25f
        val selTop = h * 0.49f
        val selH = 96.dp
        val rowH = 62.dp
        val rowWidth = w * 0.70f - (anchorX - 75.dp)

        XmbBackground(bgFile(game))

        // Miniature du logo du jeu, centrée au-dessus de la catégorie active
        val thumb = game?.let { iconImg(it) }
        if (thumb != null) {
            val tw = minOf(40f * thumb.aspect, 72f).dp
            AsyncImage(
                model = thumb.file, contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.offset(x = anchorX - tw / 2f, y = catY - 52.dp)
                    .width(tw).height(40.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(5.dp)),
            )
        }

        // Barre horizontale des catégories
        cats.forEachIndexed { i, ct ->
            CatIcon(
                kind = ct.kind, label = ct.label, selected = i == cat,
                centerX = anchorX + spacing * (i - cat), y = catY, iconSize = iconSize,
                onClick = { if (!overlayOpen) cat = i },
            )
        }

        // Liste verticale de la catégorie choisie
        val lo = (sel - 1).coerceAtLeast(0)
        val hi = (sel + 6).coerceAtMost(items.size - 1)
        for (j in lo..hi) {
            key(cat * 1000 + j) {
                val d = j - sel
                val top = when {
                    d == 0 -> selTop
                    d > 0 -> selTop + selH + rowH * (d - 1)
                    else -> selTop - rowH * (-d)
                }
                XmbRow(
                    item = items[j],
                    selected = d == 0,
                    below = d >= 0,
                    anchorX = anchorX,
                    top = top,
                    rowWidth = rowWidth,
                    onClick = {
                        if (!overlayOpen) {
                            if (d == 0) items[j].onActivate() else sels[cat] = j
                        }
                    },
                )
            }
        }

        // Date, heure, batterie (haut droite)
        HudBox(
            clockText, battery.first, battery.second,
            Modifier.align(Alignment.TopEnd).safeDrawingPadding().padding(top = 14.dp),
        )

        // "△ : Options" (bas droite)
        if (game != null) {
            Text(
                "△ : Options", color = Color.White, fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomEnd).safeDrawingPadding().padding(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x66000000))
                    .tap { if (!overlayOpen) { panelIdx = 0; showOptions = true } }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }

        if (activeRows != null) {
            ListPanel(
                title = when {
                    picker == 1 -> "Lancer avec…"
                    picker == 2 -> "Émulateur par défaut · $pickerPlatform"
                    showOptions -> game?.title ?: "Options"
                    else -> "Problèmes détectés"
                },
                rows = activeRows,
                selected = panelIdx.coerceIn(0, (activeRows.size - 1).coerceAtLeast(0)),
                onPick = { i ->
                    panelIdx = i
                    activeRows.getOrNull(i)?.let { if (it.enabled) it.onClick() }
                },
                onDismiss = { closeTop() },
            )
        }
    }
}

@Composable
private fun ListPanel(
    title: String,
    rows: List<PanelRow>,
    selected: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberLazyListState()
    // Garde la ligne choisie à la manette visible
    LaunchedEffect(selected) {
        val vis = state.layoutInfo.visibleItemsInfo
        if (vis.isNotEmpty()) {
            val first = vis.first().index
            val last = vis.last().index
            if (selected < first) state.animateScrollToItem(selected)
            else if (selected > last) state.animateScrollToItem((selected - (last - first)).coerceAtLeast(0))
        }
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xAA000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.widthIn(max = 460.dp).heightIn(max = 340.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xF0332211))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(10.dp))
                .clickable(onClick = {})
                .padding(16.dp),
        ) {
            Text(
                title, color = Color.White, fontSize = 16.sp, maxLines = 1,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp),
            )
            LazyColumn(state = state) {
                itemsIndexed(rows) { i, r ->
                    val on = i == selected
                    Text(
                        r.label,
                        color = when {
                            !r.enabled -> Color(0x88FFFFFF)
                            on -> Color(0xFF2A1A08)
                            else -> Color.White
                        },
                        fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (on) Color(0xFFF1E6D0) else Color.Transparent)
                            .clickable(enabled = r.enabled) { onPick(i) }
                            .padding(12.dp),
                    )
                }
            }
        }
    }
}

package com.you.pspl.ui

import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.launch.launchInPpsspp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private fun clock(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

@Composable
fun HomeScreen(games: List<Game>, onFocus: (Game?) -> Unit) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf(games.firstOrNull()) }
    var time by remember { mutableStateOf(clock()) }

    LaunchedEffect(selected) { onFocus(selected) }
    LaunchedEffect(Unit) { while (true) { time = clock(); delay(15_000) } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Grand fond qui change selon le jeu
        Crossfade(targetState = selected?.background, label = "bg") { bg ->
            AsyncImage(
                model = bg, contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        // Voile sombre pour que le texte reste lisible
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xCC000000), Color(0x22000000), Color(0xF0000000))
                )
            )
        )

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Barre du haut : "Games" + heure
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Games", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(time, color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.height(16.dp))

            // Rangée d'icônes : le jeu choisi est plus grand
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(games) { g ->
                    val isSel = g == selected
                    val h by animateDpAsState(if (isSel) 80.dp else 52.dp, label = "h")
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AsyncImage(
                            model = g.icon, contentDescription = g.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .height(h).aspectRatio(144f / 80f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    if (isSel) 2.dp else 0.dp,
                                    if (isSel) Color.White else Color.Transparent,
                                    RoundedCornerShape(12.dp),
                                )
                                .clickable { selected = g },
                        )
                        if (isSel) {
                            Text(
                                g.title, color = Color.White, fontSize = 11.sp,
                                maxLines = 1, modifier = Modifier.widthIn(max = 140.dp)
                                    .padding(top = 4.dp),
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            // Gros titre + bouton Jouer
            selected?.let { g ->
                Text(
                    g.title, color = Color.White, fontSize = 30.sp,
                    fontWeight = FontWeight.Bold, maxLines = 2,
                )
                Text(g.discId, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (!launchInPpsspp(ctx, g.isoUri)) {
                            Toast.makeText(ctx, "PPSSPP introuvable", Toast.LENGTH_LONG).show()
                        }
                    },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White, contentColor = Color.Black),
                ) { Text("▶  Jouer", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(16.dp))

            // Tuiles du bas
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games) { g ->
                    Box(
                        Modifier.height(86.dp).aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x55FFFFFF))
                            .clickable { selected = g }
                    ) {
                        AsyncImage(
                            model = g.background ?: g.icon, contentDescription = g.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        Text(
                            g.title, color = Color.White, fontSize = 10.sp, maxLines = 1,
                            modifier = Modifier.align(Alignment.BottomStart)
                                .background(Color(0x99000000)).padding(4.dp).fillMaxWidth(),
                        )
                    }
                }
            }
        }
    }
}

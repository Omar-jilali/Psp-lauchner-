package com.you.pspl.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.launch.launchInPpsspp

@Composable
fun HomeScreen(games: List<Game>, onFocus: (Game?) -> Unit) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf<Game?>(games.firstOrNull()) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Fond dynamique
        Crossfade(selected?.background, label = "bg") { bg ->
            AsyncImage(bg, null, Modifier.fillMaxSize().alpha(0.7f),
                contentScale = ContentScale.Crop)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            LazyVerticalGrid(GridCells.Adaptive(140.dp), Modifier.weight(1f)) {
                items(games) { g ->
                    Card(Modifier.padding(6.dp).clickable {
                        selected = g; onFocus(g)       // -> Bgm.play(g.music)
                    }) {
                        AsyncImage(g.icon, g.title)
                        Text(g.title, Modifier.padding(8.dp), maxLines = 2)
                    }
                }
            }
            selected?.let { g ->
                Button(onClick = {
                    if (!launchInPpsspp(ctx, g.isoUri)) { /* afficher "PPSSPP introuvable" */ }
                }) { Text("Jouer : ${g.title}") }
            }
        }
    }
}

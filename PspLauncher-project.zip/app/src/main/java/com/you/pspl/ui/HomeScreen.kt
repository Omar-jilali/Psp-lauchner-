package com.you.pspl.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.launch.Emu
import com.you.pspl.launch.Emulators
import com.you.pspl.launch.Recents
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.delay

private class PanelRow(
    val label: String,
    val enabled: Boolean = true,
    val onClick: () -> Unit = {},
)

private class Cat(val kind: CatKind, val label: String)

// Même ordre que sur la PS3 : pellicule, dossier, manette (Jeu), globe, violet, amis
private val CATS = listOf(
    Cat(CatKind.FILM, "Récents"),
    Cat(CatKind.FOLDER, "Émulateur"),
    Cat(CatKind.GAMEPAD, "Jeu"),
    Cat(CatKind.GLOBE, "Bibliothèque"),
    Cat(CatKind.PSN, "Paramètres"),
    Cat(CatKind.FRIENDS, "À propos"),
)
private const val GAME_CAT = 2

private fun clock(): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())

private fun fmtDate(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(t))

private fun badgeOf(g: Game): String = if (g.discId.isNotEmpty()) "PSP" else "ISO"

private fun batteryInfo(ctx: Context): Pair<Int, Boolean> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        ?: return 100 to false
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
    return pct to charging
}

@Composable
fun HomeScreen(
    games: List<Game>,
    errors: List<String>,
    onChangeFolder: () -> Unit,
    onRefresh: () -> Unit,
) {
    val ctx = LocalContext.current

    var cat by remember { mutableIntStateOf(GAME_CAT) }
    val sels = remember { mutableStateListOf(0, 0, 0, 0, 0, 0) }   // sélection de chaque catégorie
    var emuList by remember { mutableStateOf(Emulators.installed(ctx)) }
    var savedPkg by remember { mutableStateOf(Emulators.savedPkg(ctx)) }
    var picker by remember { mutableIntStateOf(0) }                // 0 fermé, 1 lancer avec, 2 défaut
    var pendingGame by remember { mutableStateOf<Game?>(null) }
    var rememberChoice by remember { mutableStateOf(true) }
    var showOptions by remember { mutableStateOf(false) }
    var showErrors by remember { mutableStateOf(false) }
    var clockText by remember { mutableStateOf(clock()) }
    var battery by remember { mutableStateOf(batteryInfo(ctx)) }
    var recents by remember { mutableStateOf(Recents.load(ctx)) }

    val savedEmu = emuList.firstOrNull { it.pkg == savedPkg }
    val overlayOpen = picker != 0 || showOptions || showErrors

    LaunchedEffect(cat, picker) { emuList = Emulators.installed(ctx) }
    LaunchedEffect(Unit) {
        while (true) {
            clockText = clock()
            battery = batteryInfo(ctx)
            delay(20_000)
        }
    }

    BackHandler(enabled = overlayOpen) {
        when {
            picker != 0 -> picker = 0
            showOptions -> showOptions = false
            else -> showErrors = false
        }
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun openPicker(mode: Int, keep: Boolean) {
        emuList = Emulators.installed(ctx)
        rememberChoice = keep
        picker = mode
    }

    fun launchWith(e: Emu, g: Game) {
        if (Emulators.launch(ctx, e, g.isoUri)) {
            Recents.add(ctx, g.isoUri.toString())
            recents = Recents.load(ctx)
        } else {
            toast("Impossible de lancer ${e.name}")
        }
    }

    fun play(g: Game) {
        emuList = Emulators.installed(ctx)
        val e = emuList.firstOrNull { it.pkg == savedPkg }
        if (e != null) launchWith(e, g) else { pendingGame = g; openPicker(1, true) }
    }

    fun choose(e: Emu) {
        if (picker == 1) {
            if (rememberChoice) { savedPkg = e.pkg; Emulators.save(ctx, e.pkg) }
            picker = 0
            pendingGame?.let { launchWith(e, it) }
        } else {
            savedPkg = e.pkg
            Emulators.save(ctx, e.pkg)
            picker = 0
        }
    }

    // ---- Contenu de la liste verticale selon la catégorie
    val items: List<XmbItem> = when (cat) {
        0 -> {
            val list = recents.mapNotNull { (u, t) ->
                games.firstOrNull { it.isoUri.toString() == u }?.let { g ->
                    XmbItem(g.icon, null, g.title, fmtDate(t), badgeOf(g)) { play(g) }
                }
            }
            list.ifEmpty {
                listOf(XmbItem(null, CatKind.FILM, "Aucun jeu lancé récemment",
                    "Les jeux que tu lances apparaîtront ici", null) {})
            }
        }
        1 -> buildList {
            emuList.forEach { e ->
                add(XmbItem(null, CatKind.GAMEPAD, e.name,
                    if (e.pkg == savedPkg) "✓ Utilisé par défaut"
                    else "Appuyer pour l'utiliser par défaut", null) {
                    savedPkg = e.pkg
                    Emulators.save(ctx, e.pkg)
                })
            }
            if (emuList.isEmpty()) {
                add(XmbItem(null, CatKind.FOLDER, "Aucun émulateur détecté",
                    "Installe PPSSPP ou un autre émulateur", null) {})
            }
            if (savedPkg != null) {
                add(XmbItem(null, CatKind.GLOBE, "Toujours demander",
                    "Choisir l'émulateur à chaque lancement", null) {
                    savedPkg = null
                    Emulators.save(ctx, null)
                })
            }
        }
        2 -> games.map { g ->
            XmbItem(g.icon, null, g.title, g.discId.ifEmpty { "Image ISO" }, badgeOf(g)) { play(g) }
        }
        3 -> buildList {
            add(XmbItem(null, CatKind.FOLDER, "Dossier des jeux",
                "Changer le dossier contenant les ISO", null) { onChangeFolder() })
            add(XmbItem(null, CatKind.GLOBE, "Actualiser la bibliothèque",
                "Relire les jeux et leurs images", null) { onRefresh() })
            if (errors.isNotEmpty()) {
                add(XmbItem(null, CatKind.FILM, "Problèmes détectés",
                    "${errors.size} fichier(s) en erreur", null) { showErrors = true })
            }
        }
        4 -> listOf(
            XmbItem(null, CatKind.GAMEPAD, "Émulateur par défaut",
                savedEmu?.name ?: "Demander à chaque fois", null) { openPicker(2, true) },
            XmbItem(null, CatKind.GLOBE, "Toujours demander l'émulateur",
                if (savedPkg == null) "Activé" else "Désactivé", null) {
                savedPkg = null
                Emulators.save(ctx, null)
            },
        )
        else -> listOf(
            XmbItem(null, CatKind.PSN, "PSP Launcher", "Version 2.0", null) {},
            XmbItem(null, CatKind.FOLDER, "Bibliothèque", "${games.size} jeu(x) trouvé(s)", null) {},
        )
    }
    val sel = sels[cat].coerceIn(0, (items.size - 1).coerceAtLeast(0))
    val game: Game? = if (cat == GAME_CAT) games.getOrNull(sel) else null

    fun moveCat(d: Int) { if (!overlayOpen) cat = (cat + d).coerceIn(0, CATS.size - 1) }
    fun moveItem(d: Int) {
        if (!overlayOpen) sels[cat] = (sel + d).coerceIn(0, (items.size - 1).coerceAtLeast(0))
    }
    val onMoveCat by rememberUpdatedState<(Int) -> Unit>({ d -> moveCat(d) })
    val onMoveItem by rememberUpdatedState<(Int) -> Unit>({ d -> moveItem(d) })

    val pickerRows: List<PanelRow> = buildList {
        if (emuList.isEmpty()) add(PanelRow("Aucun émulateur connu détecté", enabled = false))
        emuList.forEach { e ->
            val mark = if (picker == 2 && e.pkg == savedPkg) "✓  " else ""
            add(PanelRow(mark + e.name) { choose(e) })
        }
        if (picker == 1) {
            add(PanelRow("📂  Autre application…") {
                picker = 0
                pendingGame?.let {
                    if (!Emulators.chooser(ctx, it.isoUri)) toast("Aucune application trouvée")
                }
            })
            add(PanelRow((if (rememberChoice) "☑" else "☐") + "  Se souvenir de mon choix") {
                rememberChoice = !rememberChoice
            })
            add(PanelRow("Annuler") { picker = 0 })
        } else {
            if (savedPkg != null) {
                add(PanelRow("↺  Toujours demander") {
                    savedPkg = null
                    Emulators.save(ctx, null)
                    picker = 0
                })
            }
            add(PanelRow("Retour") { picker = 0 })
        }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var dx = 0f
            var dy = 0f
            detectDragGestures(
                onDragStart = { dx = 0f; dy = 0f },
                onDragEnd = {
                    if (abs(dx) > abs(dy)) {
                        if (dx < -70f) onMoveCat(1) else if (dx > 70f) onMoveCat(-1)
                    } else {
                        if (dy < -70f) onMoveItem(1) else if (dy > 70f) onMoveItem(-1)
                    }
                },
                onDrag = { change, amount ->
                    change.consume()
                    dx += amount.x
                    dy += amount.y
                },
            )
        }
    ) {
        val w = maxWidth
        val h = maxHeight
        val anchorX = w * 0.293f          // colonne active (comme sur la PS3)
        val spacing = w * 0.107f
        val iconSize = maxOf(w * 0.05f, 34.dp)
        val catY = h * 0.25f
        val selTop = h * 0.49f
        val selH = 88.dp
        val rowH = 60.dp
        val rowWidth = w * 0.70f - (anchorX - 75.dp)

        XmbBackground()

        // Miniature du jeu, centrée au-dessus de la catégorie active
        val thumb = game?.icon
        if (thumb != null) {
            AsyncImage(
                model = thumb, contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.offset(x = anchorX - 36.dp, y = catY - 52.dp)
                    .width(72.dp).height(40.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(5.dp)),
            )
        }

        // Barre horizontale des catégories
        CATS.forEachIndexed { i, c ->
            CatIcon(
                kind = c.kind, label = c.label, selected = i == cat,
                centerX = anchorX + spacing * (i - cat), y = catY, iconSize = iconSize,
                onClick = { if (!overlayOpen) cat = i },
            )
        }

        // Liste verticale de la catégorie choisie
        val lo = (sel - 1).coerceAtLeast(0)
        val hi = (sel + 6).coerceAtMost(items.size - 1)
        for (j in lo..hi) {
            key(cat * 1000 + j) {
                val d = j - sel
                val top = when {
                    d == 0 -> selTop
                    d > 0 -> selTop + selH + rowH * (d - 1)
                    else -> selTop - rowH * (-d)
                }
                XmbRow(
                    item = items[j],
                    selected = d == 0,
                    below = d >= 0,
                    anchorX = anchorX,
                    top = top,
                    rowWidth = rowWidth,
                    onClick = {
                        if (!overlayOpen) {
                            if (d == 0) items[j].onActivate() else sels[cat] = j
                        }
                    },
                )
            }
        }

        // Date, heure, batterie (haut droite)
        HudBox(
            clockText, battery.first, battery.second,
            Modifier.align(Alignment.TopEnd).safeDrawingPadding().padding(top = 14.dp),
        )

        // "△ : Options" (bas droite)
        if (game != null) {
            Text(
                "△ : Options", color = Color.White, fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomEnd).safeDrawingPadding().padding(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x66000000))
                    .tap { if (!overlayOpen) showOptions = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }

        if (showOptions && game != null) {
            ListPanel(
                title = game.title,
                rows = listOf(
                    PanelRow("▶  Lancer") { showOptions = false; play(game) },
                    PanelRow("🎮  Lancer avec un autre émulateur…") {
                        showOptions = false
                        pendingGame = game
                        openPicker(1, false)
                    },
                    PanelRow("⭐  Émulateur par défaut…") {
                        showOptions = false
                        openPicker(2, true)
                    },
                    PanelRow("Fermer") { showOptions = false },
                ),
                onDismiss = { showOptions = false },
            )
        }
        if (showErrors) {
            ListPanel(
                title = "Problèmes détectés",
                rows = errors.take(30).map { PanelRow(it, enabled = false) } +
                    PanelRow("Fermer") { showErrors = false },
                onDismiss = { showErrors = false },
            )
        }
        if (picker != 0) {
            ListPanel(
                title = if (picker == 1) "Lancer avec…" else "Émulateur par défaut",
                rows = pickerRows,
                onDismiss = { picker = 0 },
            )
        }
    }
}

@Composable
private fun ListPanel(title: String, rows: List<PanelRow>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xAA000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.widthIn(max = 440.dp).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xF0332211))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(10.dp))
                .clickable(onClick = {})
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                title, color = Color.White, fontSize = 16.sp, maxLines = 1,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp),
            )
            rows.forEach { r ->
                Text(
                    r.label,
                    color = if (r.enabled) Color.White else Color(0x88FFFFFF),
                    fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = r.enabled) { r.onClick() }
                        .padding(12.dp),
                )
            }
        }
    }
}

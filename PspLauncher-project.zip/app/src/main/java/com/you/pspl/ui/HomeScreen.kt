package com.you.pspl.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.you.pspl.data.Game
import com.you.pspl.launch.Emu
import com.you.pspl.launch.Emulators
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.delay

private class PanelRow(
    val label: String,
    val enabled: Boolean = true,
    val onClick: () -> Unit = {},
)

private class Cat(val glyph: String, val label: String)

private val CATS = listOf(
    Cat("⚙️", "Paramètres"),
    Cat("🎮", "Jeu"),
    Cat("🕹️", "Émulateur"),
)

private fun clock(): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())

private fun batteryPct(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 100
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (level >= 0 && scale > 0) level * 100 / scale else 100
}

@Composable
fun HomeScreen(
    games: List<Game>,
    errors: List<String>,
    onChangeFolder: () -> Unit,
    onRefresh: () -> Unit,
) {
    val ctx = LocalContext.current

    var cat by remember { mutableIntStateOf(1) }                 // 1 = "Jeu"
    val sels = remember { mutableStateListOf(0, 0, 0) }          // sélection de chaque catégorie
    var emuList by remember { mutableStateOf(Emulators.installed(ctx)) }
    var savedPkg by remember { mutableStateOf(Emulators.savedPkg(ctx)) }
    var picker by remember { mutableIntStateOf(0) }              // 0 fermé, 1 lancer avec, 2 défaut
    var rememberChoice by remember { mutableStateOf(true) }
    var showOptions by remember { mutableStateOf(false) }
    var showErrors by remember { mutableStateOf(false) }
    var clockText by remember { mutableStateOf(clock()) }
    var battery by remember { mutableIntStateOf(batteryPct(ctx)) }

    val savedEmu = emuList.firstOrNull { it.pkg == savedPkg }
    val overlayOpen = picker != 0 || showOptions || showErrors

    LaunchedEffect(cat, picker) { emuList = Emulators.installed(ctx) }
    LaunchedEffect(Unit) {
        while (true) {
            clockText = clock()
            battery = batteryPct(ctx)
            delay(20_000)
        }
    }

    BackHandler(enabled = overlayOpen) {
        when {
            picker != 0 -> picker = 0
            showOptions -> showOptions = false
            else -> showErrors = false
        }
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun openPicker(mode: Int, keep: Boolean) {
        emuList = Emulators.installed(ctx)
        rememberChoice = keep
        picker = mode
    }

    fun launchWith(e: Emu, g: Game) {
        if (!Emulators.launch(ctx, e, g.isoUri)) toast("Impossible de lancer ${e.name}")
    }

    fun play(g: Game) {
        emuList = Emulators.installed(ctx)
        val e = emuList.firstOrNull { it.pkg == savedPkg }
        if (e != null) launchWith(e, g) else openPicker(1, true)
    }

    fun choose(e: Emu) {
        if (picker == 1) {
            if (rememberChoice) { savedPkg = e.pkg; Emulators.save(ctx, e.pkg) }
            picker = 0
            games.getOrNull(sels[1])?.let { launchWith(e, it) }
        } else {
            savedPkg = e.pkg
            Emulators.save(ctx, e.pkg)
            picker = 0
        }
    }

    // ---- Contenu de la liste verticale selon la catégorie
    val items: List<XmbItem> = when (cat) {
        0 -> buildList {
            add(XmbItem(null, "🎮", "Émulateur par défaut",
                savedEmu?.name ?: "Demander à chaque fois", null) { openPicker(2, true) })
            add(XmbItem(null, "📁", "Dossier des jeux",
                "Changer le dossier contenant les ISO", null) { onChangeFolder() })
            add(XmbItem(null, "🔄", "Actualiser la bibliothèque",
                "Relire les jeux et leurs images", null) { onRefresh() })
            if (errors.isNotEmpty()) {
                add(XmbItem(null, "⚠️", "Problèmes détectés",
                    "${errors.size} fichier(s) en erreur", null) { showErrors = true })
            }
        }
        1 -> games.map { g ->
            XmbItem(
                g.icon, g.title.take(2).uppercase(), g.title,
                g.discId.ifEmpty { "Image ISO" },
                if (g.discId.isNotEmpty()) "PSP" else "ISO",
            ) { play(g) }
        }
        else -> buildList {
            emuList.forEach { e ->
                add(XmbItem(null, "🕹️", e.name,
                    if (e.pkg == savedPkg) "✓ Utilisé par défaut"
                    else "Appuyer pour l'utiliser par défaut", null) {
                    savedPkg = e.pkg
                    Emulators.save(ctx, e.pkg)
                })
            }
            if (emuList.isEmpty()) {
                add(XmbItem(null, "⚠️", "Aucun émulateur détecté",
                    "Installe PPSSPP ou un autre émulateur", null) {})
            }
            if (savedPkg != null) {
                add(XmbItem(null, "↺", "Toujours demander",
                    "Choisir l'émulateur à chaque lancement", null) {
                    savedPkg = null
                    Emulators.save(ctx, null)
                })
            }
        }
    }
    val sel = sels[cat].coerceIn(0, (items.size - 1).coerceAtLeast(0))
    val game: Game? = if (cat == 1) games.getOrNull(sel) else null

    fun moveCat(d: Int) { if (!overlayOpen) cat = (cat + d).coerceIn(0, CATS.size - 1) }
    fun moveItem(d: Int) {
        if (!overlayOpen) sels[cat] = (sel + d).coerceIn(0, (items.size - 1).coerceAtLeast(0))
    }
    val onMoveCat by rememberUpdatedState<(Int) -> Unit>({ d -> moveCat(d) })
    val onMoveItem by rememberUpdatedState<(Int) -> Unit>({ d -> moveItem(d) })

    // ---- Panneaux (fenêtres) : choix d'émulateur, options, problèmes
    val pickerRows: List<PanelRow> = buildList {
        if (emuList.isEmpty()) add(PanelRow("Aucun émulateur connu détecté", enabled = false))
        emuList.forEach { e ->
            val mark = if (picker == 2 && e.pkg == savedPkg) "✓  " else ""
            add(PanelRow(mark + e.name) { choose(e) })
        }
        if (picker == 1) {
            add(PanelRow("📂  Autre application…") {
                picker = 0
                games.getOrNull(sels[1])?.let {
                    if (!Emulators.chooser(ctx, it.isoUri)) toast("Aucune application trouvée")
                }
            })
            add(PanelRow((if (rememberChoice) "☑" else "☐") + "  Se souvenir de mon choix") {
                rememberChoice = !rememberChoice
            })
            add(PanelRow("Annuler") { picker = 0 })
        } else {
            if (savedPkg != null) {
                add(PanelRow("↺  Toujours demander") {
                    savedPkg = null
                    Emulators.save(ctx, null)
                    picker = 0
                })
            }
            add(PanelRow("Retour") { picker = 0 })
        }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var dx = 0f
            var dy = 0f
            detectDragGestures(
                onDragStart = { dx = 0f; dy = 0f },
                onDragEnd = {
                    if (abs(dx) > abs(dy)) {
                        if (dx < -70f) onMoveCat(1) else if (dx > 70f) onMoveCat(-1)
                    } else {
                        if (dy < -70f) onMoveItem(1) else if (dy > 70f) onMoveItem(-1)
                    }
                },
                onDrag = { change, amount ->
                    change.consume()
                    dx += amount.x
                    dy += amount.y
                },
            )
        }
    ) {
        val w = maxWidth
        val h = maxHeight
        val anchorX = w * 0.29f
        val spacing = w * 0.115f
        val catY = h * 0.15f
        val selTop = h * 0.40f
        val selH = 76.dp
        val rowH = 56.dp
        val rowWidth = w * 0.68f - (anchorX - 64.dp)

        XmbBackground(game?.background)

        // Catégories (rangée du haut)
        CATS.forEachIndexed { i, c ->
            CatIcon(
                glyph = c.glyph, label = c.label, selected = i == cat,
                centerX = anchorX + spacing * (i - cat), y = catY,
                onClick = { if (!overlayOpen) cat = i },
            )
        }

        // Liste verticale de la catégorie choisie
        val lo = (sel - 1).coerceAtLeast(0)
        val hi = (sel + 6).coerceAtMost(items.size - 1)
        for (j in lo..hi) {
            key(cat * 1000 + j) {
                val d = j - sel
                val top = when {
                    d == 0 -> selTop
                    d > 0 -> selTop + selH + rowH * (d - 1)
                    else -> selTop - rowH * (-d)
                }
                XmbRow(
                    item = items[j],
                    selected = d == 0,
                    below = d >= 0,
                    anchorX = anchorX,
                    top = top,
                    rowWidth = rowWidth,
                    onClick = {
                        if (!overlayOpen) {
                            if (d == 0) items[j].onActivate() else sels[cat] = j
                        }
                    },
                )
            }
        }

        // Horloge + batterie (haut droite)
        Row(
            Modifier.align(Alignment.TopEnd).safeDrawingPadding().padding(top = 14.dp)
                .clip(RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                .background(Color(0x33FFFFFF))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                .padding(horizontal = 18.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(clockText, color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.width(14.dp))
            Text("🔋 $battery%", color = Color.White, fontSize = 16.sp)
        }

        // "△ : Options" (bas droite)
        if (game != null) {
            Text(
                "△ : Options", color = Color.White, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.BottomEnd).safeDrawingPadding().padding(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x66000000))
                    .tap { if (!overlayOpen) showOptions = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }

        if (showOptions && game != null) {
            ListPanel(
                title = game.title,
                rows = listOf(
                    PanelRow("▶  Lancer") { showOptions = false; play(game) },
                    PanelRow("🎮  Lancer avec un autre émulateur…") {
                        showOptions = false; openPicker(1, false)
                    },
                    PanelRow("⭐  Émulateur par défaut…") {
                        showOptions = false; openPicker(2, true)
                    },
                    PanelRow("Fermer") { showOptions = false },
                ),
                onDismiss = { showOptions = false },
            )
        }
        if (showErrors) {
            ListPanel(
                title = "Problèmes détectés",
                rows = errors.take(30).map { PanelRow(it, enabled = false) } +
                    PanelRow("Fermer") { showErrors = false },
                onDismiss = { showErrors = false },
            )
        }
        if (picker != 0) {
            ListPanel(
                title = if (picker == 1) "Lancer avec…" else "Émulateur par défaut",
                rows = pickerRows,
                onDismiss = { picker = 0 },
            )
        }
    }
}

@Composable
private fun ListPanel(title: String, rows: List<PanelRow>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xAA000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.widthIn(max = 440.dp).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xF0332211))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(14.dp))
                .clickable(onClick = {})
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                title, color = Color.White, fontSize = 16.sp, maxLines = 1,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp),
            )
            rows.forEach { r ->
                Text(
                    r.label,
                    color = if (r.enabled) Color.White else Color(0x88FFFFFF),
                    fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = r.enabled) { r.onClick() }
                        .padding(12.dp),
                )
            }
        }
    }
}

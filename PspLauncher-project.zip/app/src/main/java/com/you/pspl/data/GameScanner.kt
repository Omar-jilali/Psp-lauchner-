package com.you.pspl.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** Une image + son rapport largeur/hauteur. */
class Img(val file: File, val aspect: Float)

data class Game(
    val key: String,          // identifiant du cache de ce jeu
    val title: String,
    val discId: String,
    val platform: String,     // PSP, PS3, PS2... (d'après le sous-dossier)
    val isoUri: Uri,
    val icon: File?,
    val iconAspect: Float,
    val background: File?,
    val dir: File,            // dossier de cache (images extraites + personnalisées)
) {
    val badge: String get() = platform.uppercase().take(8)
}

class ScanResult(val games: List<Game>, val errors: List<String>)

private class Found(val file: DocumentFile, val path: List<String>, val rootPlatform: String?)

object GameScanner {
    private val ORDER = listOf("PS3", "PSP", "PS2", "PS1", "Wii", "Wii U", "GameCube", "Dreamcast")

    /** Reconnaît une console d'après le nom d'un dossier ("PSP Game's", "PS3 Game"...). */
    fun detectPlatform(name: String): String? {
        val n = name.lowercase().filter { it.isLetterOrDigit() }
        return when {
            "ps3" in n || "playstation3" in n -> "PS3"
            "ps2" in n || "playstation2" in n -> "PS2"
            "psp" in n || "playstationportable" in n -> "PSP"
            "ps1" in n || "psx" in n || "psone" in n || "playstation1" in n -> "PS1"
            "wiiu" in n -> "Wii U"
            "wii" in n -> "Wii"
            "gamecube" in n || n == "gc" || "ngc" in n -> "GameCube"
            "dreamcast" in n -> "Dreamcast"
            else -> null
        }
    }

    fun sortPlatforms(list: List<String>): List<String> =
        list.sortedWith(compareBy({ p -> ORDER.indexOf(p).let { if (it < 0) 99 else it } }, { it }))

    /** "Xbox Games" -> "Xbox" */
    private fun cleanLabel(name: String): String {
        val cleaned = name.replace(Regex("(?i)\\b(games?|game's|jeux|jeu)\\b"), "")
            .replace("'", "").trim()
        return cleaned.ifEmpty { name.trim() }
    }

    fun imageAspect(f: File): Float {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        return if (o.outWidth > 0 && o.outHeight > 0) o.outWidth.toFloat() / o.outHeight else 1.8f
    }

    fun customImg(dir: File, prefix: String): Img? =
        dir.listFiles { f -> f.name.startsWith(prefix) }?.firstOrNull()
            ?.let { Img(it, imageAspect(it)) }

    /** Vide le cache d'images extraites, mais garde les images personnalisées. */
    fun clearCache(ctx: Context) {
        File(ctx.filesDir, "cache").deleteRecursively()   // ancien dossier
        File(ctx.filesDir, "library").listFiles()?.forEach { d ->
            d.listFiles()?.filter { !it.name.startsWith("custom_") }?.forEach { it.delete() }
        }
    }

    fun scan(ctx: Context, treeUri: Uri): ScanResult {
        val root = DocumentFile.fromTreeUri(ctx, treeUri)
            ?: return ScanResult(emptyList(), listOf("Dossier inaccessible"))
        val rootPlatform = root.name?.let { detectPlatform(it) }
        val found = mutableListOf<Found>()
        walk(root, emptyList(), 0, rootPlatform, found)

        val games = mutableListOf<Game>()
        val errors = mutableListOf<String>()
        for (f in found) {
            try {
                games += index(ctx, f)
            } catch (t: Throwable) {
                errors += "${f.file.name} : ${t.message ?: t.javaClass.simpleName}"
            }
        }
        return ScanResult(games.sortedBy { it.title.lowercase() }, errors)
    }

    private fun walk(
        dir: DocumentFile, path: List<String>, depth: Int,
        rootPlatform: String?, out: MutableList<Found>,
    ) {
        if (depth > 6) return
        for (c in dir.listFiles()) {
            val nm = c.name ?: continue
            if (c.isDirectory) walk(c, path + nm, depth + 1, rootPlatform, out)
            else if (nm.endsWith(".iso", ignoreCase = true)) out += Found(c, path, rootPlatform)
        }
    }

    private fun isPng(b: ByteArray) =
        b.size > 8 && b[1].toInt() == 0x50 && b[2].toInt() == 0x4E && b[3].toInt() == 0x47

    private fun index(ctx: Context, f: Found): Game {
        val df = f.file
        val name = df.name ?: "jeu.iso"
        val key = Integer.toHexString(df.uri.toString().hashCode())
        val dir = File(ctx.filesDir, "library/$key").apply { mkdirs() }
        val info = File(dir, "info.txt")
        val iconF = File(dir, "icon.png")
        val bgF = File(dir, "bg.png")

        var title = name.substringBeforeLast('.')
        var discId = ""
        var content = ""          // console reconnue d'après le contenu de l'ISO

        if (info.exists()) {
            val lines = info.readLines()
            if (lines.isNotEmpty() && lines[0].isNotBlank()) title = lines[0]
            discId = lines.getOrNull(1) ?: ""
            content = lines.getOrNull(2) ?: ""
        } else {
            runCatching {
                PspIso(ctx, df.uri).use { iso ->
                    var gameDir: String? = null
                    val sfoBytes = iso.readFile("PSP_GAME/PARAM.SFO")
                        ?.also { gameDir = "PSP_GAME"; content = "PSP" }
                        ?: iso.readFile("PS3_GAME/PARAM.SFO")
                            ?.also { gameDir = "PS3_GAME"; content = "PS3" }

                    if (sfoBytes != null) {
                        runCatching {
                            val sfo = parseSfo(sfoBytes)
                            sfo["TITLE"]?.replace("\n", " ")?.trim()
                                ?.takeIf { it.isNotEmpty() }?.let { title = it }
                            discId = sfo["DISC_ID"] ?: sfo["TITLE_ID"] ?: ""
                        }
                    }
                    val gd = gameDir
                    if (gd != null) {
                        iso.readFile("$gd/ICON0.PNG")?.takeIf { isPng(it) }?.let { iconF.writeBytes(it) }
                        (iso.readFile("$gd/PIC1.PNG") ?: iso.readFile("$gd/PIC0.PNG"))
                            ?.takeIf { isPng(it) }?.let { bgF.writeBytes(it) }
                    } else {
                        // PS2 / PS1 : l'identifiant du jeu est dans SYSTEM.CNF
                        iso.readFile("SYSTEM.CNF")?.let { bytes ->
                            val txt = String(bytes, Charsets.ISO_8859_1)
                            Regex("([A-Z]{4})[_-](\\d{3})\\.(\\d{2})").find(txt)?.let { m ->
                                discId = m.groupValues[1] + "-" + m.groupValues[2] + m.groupValues[3]
                                content = if (Regex("BOOT2", RegexOption.IGNORE_CASE).containsMatchIn(txt))
                                    "PS2" else "PS1"
                            }
                        }
                    }
                }
            }
            info.writeText(title + "\n" + discId + "\n" + content)
        }

        var fromPath: String? = null
        for (nm in f.path.reversed()) {
            val p = detectPlatform(nm)
            if (p != null) { fromPath = p; break }
        }
        val platform = fromPath
            ?: f.rootPlatform
            ?: content.takeIf { it.isNotEmpty() }
            ?: f.path.firstOrNull()?.let { cleanLabel(it) }
            ?: "Autre"

        return Game(
            key = key,
            title = title,
            discId = discId,
            platform = platform,
            isoUri = df.uri,
            icon = iconF.takeIf { it.exists() },
            iconAspect = if (iconF.exists()) imageAspect(iconF) else 1.8f,
            background = bgF.takeIf { it.exists() },
            dir = dir,
        )
    }
}

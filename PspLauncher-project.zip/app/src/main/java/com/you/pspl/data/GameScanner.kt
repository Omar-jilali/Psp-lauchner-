package com.you.pspl.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

data class Game(
    val title: String,
    val discId: String,
    val isoUri: Uri,
    val icon: File?,
    val background: File?,
    val music: File?,   // SND0 brut (.at3), converti en m4a à la volée
    val dir: File,      // dossier de cache de ce jeu
)

object GameScanner {
    fun scan(ctx: Context, treeUri: Uri): List<Game> {
        val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: return emptyList()
        return walk(root).mapNotNull { f ->
            runCatching { index(ctx, f) }.getOrNull()
        }
    }

    private fun walk(dir: DocumentFile): List<DocumentFile> =
        dir.listFiles().flatMap {
            if (it.isDirectory) walk(it)
            else if (it.name?.endsWith(".iso", true) == true) listOf(it) else emptyList()
        }

    private fun index(ctx: Context, f: DocumentFile): Game {
        PspIso(ctx, f.uri).use { iso ->
            val sfo = parseSfo(iso.readFile("PSP_GAME/PARAM.SFO")!!)
            val id = sfo["DISC_ID"] ?: f.name!!.hashCode().toString()
            val dir = File(ctx.filesDir, "cache/$id").apply { mkdirs() }

            fun dump(src: String, dst: String): File? {
                val out = File(dir, dst)
                if (out.exists()) return out            // déjà en cache
                val data = iso.readFile(src) ?: return null
                out.writeBytes(data); return out
            }
            return Game(
                title = sfo["TITLE"] ?: f.name!!,
                discId = id,
                isoUri = f.uri,
                icon = dump("PSP_GAME/ICON0.PNG", "icon.png"),
                background = dump("PSP_GAME/PIC1.PNG", "bg.png")   // PIC1 = fond plein écran
                    ?: dump("PSP_GAME/PIC0.PNG", "bg.png"),
                music = dump("PSP_GAME/SND0.AT3", "bgm.at3"),
                dir = dir,
            )
        }
    }
}

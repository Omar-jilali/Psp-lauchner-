package com.you.pspl.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

data class Game(
    val title: String,
    val discId: String,
    val isoUri: Uri,
    val icon: File?,
    val background: File?,
)

class ScanResult(val games: List<Game>, val errors: List<String>)

object GameScanner {
    fun scan(ctx: Context, treeUri: Uri): ScanResult {
        val root = DocumentFile.fromTreeUri(ctx, treeUri)
            ?: return ScanResult(emptyList(), listOf("Dossier inaccessible"))
        val games = mutableListOf<Game>()
        val errors = mutableListOf<String>()
        for (f in walk(root, 0)) {
            try {
                games += index(ctx, f)
            } catch (t: Throwable) {
                errors += "${f.name} : ${t.message ?: t.javaClass.simpleName}"
            }
        }
        return ScanResult(games.sortedBy { it.title.lowercase() }, errors)
    }

    private fun walk(dir: DocumentFile, depth: Int): List<DocumentFile> {
        if (depth > 6) return emptyList()
        val out = mutableListOf<DocumentFile>()
        for (f in dir.listFiles()) {
            if (f.isDirectory) out += walk(f, depth + 1)
            else if (f.name?.endsWith(".iso", ignoreCase = true) == true) out += f
        }
        return out
    }

    /**
     * Les ISO qui ne sont pas des jeux PSP (PS2, GameCube...) sont listées
     * quand même, avec le nom du fichier comme titre.
     */
    private fun index(ctx: Context, f: DocumentFile): Game {
        val name = f.name ?: "jeu.iso"
        val key = Integer.toHexString(f.uri.toString().hashCode())
        val dir = File(ctx.filesDir, "cache/$key").apply { mkdirs() }
        val info = File(dir, "info.txt")
        val iconF = File(dir, "icon.png")
        val bgF = File(dir, "bg.png")

        var title = name.substringBeforeLast('.')
        var discId = ""

        if (info.exists()) {
            val lines = info.readLines()
            if (lines.isNotEmpty() && lines[0].isNotBlank()) title = lines[0]
            discId = lines.getOrNull(1) ?: ""
        } else {
            runCatching {
                PspIso(ctx, f.uri).use { iso ->
                    iso.readFile("PSP_GAME/PARAM.SFO")?.let { bytes ->
                        val sfo = parseSfo(bytes)
                        sfo["TITLE"]?.replace("\n", " ")?.trim()
                            ?.takeIf { it.isNotEmpty() }?.let { title = it }
                        discId = sfo["DISC_ID"] ?: ""
                    }
                    iso.readFile("PSP_GAME/ICON0.PNG")?.let { iconF.writeBytes(it) }
                    (iso.readFile("PSP_GAME/PIC1.PNG") ?: iso.readFile("PSP_GAME/PIC0.PNG"))
                        ?.let { bgF.writeBytes(it) }
                }
            }
            info.writeText(title + "\n" + discId)
        }
        return Game(
            title = title,
            discId = discId,
            isoUri = f.uri,
            icon = iconF.takeIf { it.exists() },
            background = bgF.takeIf { it.exists() },
        )
    }
}

package com.you.pspl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.you.pspl.data.Game
import com.you.pspl.data.GameScanner
import com.you.pspl.player.Bgm
import com.you.pspl.ui.HomeScreen
import com.you.pspl.ui.Nav
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlinx.coroutines.flow.MutableSharedFlow

class MainActivity : ComponentActivity() {
    private var games by mutableStateOf(listOf<Game>())
    private var loading by mutableStateOf(false)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private val navFlow = MutableSharedFlow<Nav>(extraBufferCapacity = 16)

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("tree", uri.toString()).apply()
            load(uri)
        }
    }

    private fun load(uri: Uri) {
        loading = true
        thread {
            val g = runCatching { GameScanner.scan(this, uri) }.getOrDefault(emptyList())
            runOnUiThread { games = g; loading = false }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs.getString("tree", null)?.let { load(Uri.parse(it)) }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    if (games.isEmpty()) {
                        Column(Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            if (loading) CircularProgressIndicator()
                            else Button(onClick = { picker.launch(null) }) {
                                Text("Choisir le dossier des ISO")
                            }
                        }
                    } else HomeScreen(games, navFlow)
                }
            }
        }
    }

    // ---- Manette : croix directionnelle, A/✕ = jouer, Y/△ = options, B/○ = retour
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val n = when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> Nav.LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> Nav.RIGHT
                KeyEvent.KEYCODE_DPAD_UP -> Nav.UP
                KeyEvent.KEYCODE_DPAD_DOWN -> Nav.DOWN
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> Nav.SELECT
                KeyEvent.KEYCODE_BUTTON_B -> Nav.BACK
                KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_START -> Nav.OPTIONS
                else -> null
            }
            if (n != null) {
                val repeatable = n == Nav.LEFT || n == Nav.RIGHT || n == Nav.UP || n == Nav.DOWN
                if (e.repeatCount == 0 || repeatable) navFlow.tryEmit(n)
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---- Joystick gauche
    private var latchX = 0
    private var latchY = 0
    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE) {
            latchX = edge(e.getAxisValue(MotionEvent.AXIS_X), latchX, Nav.LEFT, Nav.RIGHT)
            latchY = edge(e.getAxisValue(MotionEvent.AXIS_Y), latchY, Nav.UP, Nav.DOWN)
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    private fun edge(v: Float, latched: Int, neg: Nav, pos: Nav): Int {
        val s = when {
            v > 0.6f -> 1
            v < -0.6f -> -1
            abs(v) < 0.3f -> 0
            else -> latched
        }
        if (s != latched && s != 0) navFlow.tryEmit(if (s > 0) pos else neg)
        return s
    }

    override fun onStart() { super.onStart(); Bgm.resume() }
    override fun onStop() { super.onStop(); Bgm.stop() }
}

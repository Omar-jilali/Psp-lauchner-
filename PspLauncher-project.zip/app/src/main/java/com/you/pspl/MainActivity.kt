package com.you.pspl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import com.you.pspl.data.GameScanner
import com.you.pspl.data.Library
import com.you.pspl.data.Platform
import com.you.pspl.player.Bgm
import com.you.pspl.ui.HomeScreen
import com.you.pspl.ui.Nav
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlinx.coroutines.flow.MutableSharedFlow

class MainActivity : ComponentActivity() {
    private val libs = Platform.entries.associateWith { Library(it) }
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private val navFlow = MutableSharedFlow<Nav>(extraBufferCapacity = 16)
    private var pendingPick = Platform.PSP

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("tree_${pendingPick.name}", uri.toString()).apply()
            scan(pendingPick)
        }
    }

    private fun pickFolder(p: Platform) { pendingPick = p; picker.launch(null) }

    private fun scan(p: Platform) {
        val lib = libs.getValue(p)
        val tree = prefs.getString("tree_${p.name}", null) ?: return
        lib.hasFolder = true
        lib.loading = true
        thread {
            val g = runCatching { GameScanner.scan(this, p, Uri.parse(tree)) }
                .onFailure { Log.e("Scan", "Scan ${p.name} échoué", it) }
                .getOrDefault(emptyList())
            runOnUiThread { lib.games = g; lib.loading = false }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ancienne version : un seul dossier "tree" -> bibliothèque PSP
        if (prefs.getString("tree_PSP", null) == null)
            prefs.getString("tree", null)?.let { prefs.edit().putString("tree_PSP", it).apply() }
        Platform.entries.forEach { scan(it) }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    HomeScreen(libs.values.toList(), navFlow, ::pickFolder, ::scan)
                }
            }
        }
    }

    // ---- Manette PS4 / PS5 (DualShock 4 / DualSense) :
    //  ✕ = BUTTON_A (valider) · ○ = BUTTON_B (retour) · OPTIONS = BUTTON_START
    //  L1 / R1 = changer de bibliothèque · croix directionnelle + stick gauche = navigation
    private var dpadKeys = false

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val n = when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> Nav.LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> Nav.RIGHT
                KeyEvent.KEYCODE_DPAD_UP -> Nav.UP
                KeyEvent.KEYCODE_DPAD_DOWN -> Nav.DOWN
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> Nav.SELECT
                KeyEvent.KEYCODE_BUTTON_B -> Nav.BACK
                KeyEvent.KEYCODE_BUTTON_START -> Nav.OPTIONS
                KeyEvent.KEYCODE_BUTTON_L1 -> Nav.TAB_PREV
                KeyEvent.KEYCODE_BUTTON_R1 -> Nav.TAB_NEXT
                else -> null
            }
            if (n != null) {
                val dir = n == Nav.LEFT || n == Nav.RIGHT || n == Nav.UP || n == Nav.DOWN
                if (dir) dpadKeys = true
                if (e.repeatCount == 0 || dir) navFlow.tryEmit(n)
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---- Stick gauche + croix (axes HAT) avec répétition quand on maintient
    private val handler = Handler(Looper.getMainLooper())
    private var held: Nav? = null
    private val repeat = object : Runnable {
        override fun run() {
            held?.let { navFlow.tryEmit(it); handler.postDelayed(this, 120) }
        }
    }

    private fun hold(n: Nav?) {
        if (n == held) return
        held = n
        handler.removeCallbacks(repeat)
        if (n != null) { navFlow.tryEmit(n); handler.postDelayed(repeat, 380) }
    }

    private fun axisDir(x: Float, y: Float): Nav? {
        val th = if (held != null) 0.35f else 0.6f   // hystérésis
        val ax = abs(x); val ay = abs(y)
        return when {
            ax < th && ay < th -> null
            ax >= ay -> if (x > 0) Nav.RIGHT else Nav.LEFT
            else -> if (y > 0) Nav.DOWN else Nav.UP
        }
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE) {
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            // Si la croix arrive déjà en touches DPAD, on ignore le HAT (évite le double déplacement)
            val x = if (!dpadKeys && hx != 0f) hx else e.getAxisValue(MotionEvent.AXIS_X)
            val y = if (!dpadKeys && hy != 0f) hy else e.getAxisValue(MotionEvent.AXIS_Y)
            hold(axisDir(x, y))
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) hold(null)
    }

    override fun onStart() { super.onStart(); Bgm.resume() }
    override fun onStop() { super.onStop(); hold(null); Bgm.stop() }
}

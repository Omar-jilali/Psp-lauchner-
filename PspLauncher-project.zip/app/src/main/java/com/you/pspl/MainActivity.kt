package com.you.pspl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.you.pspl.data.Game
import com.you.pspl.data.GameScanner
import com.you.pspl.data.ScanResult
import com.you.pspl.ui.CrashScreen
import com.you.pspl.ui.EmptyScreen
import com.you.pspl.ui.HomeScreen
import com.you.pspl.ui.LoadingScreen
import java.io.File
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private var games by mutableStateOf(listOf<Game>())
    private var errors by mutableStateOf(listOf<String>())
    private var loading by mutableStateOf(false)
    private var scanned by mutableStateOf(false)
    private var crash by mutableStateOf<String?>(null)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.edit().putString("tree", uri.toString()).apply()
            load(uri)
        }
    }

    private fun pickFolder() { folderPicker.launch(null) }

    private fun load(uri: Uri) {
        loading = true
        thread {
            val result = try {
                GameScanner.scan(this, uri)
            } catch (t: Throwable) {
                ScanResult(emptyList(), listOf("Analyse impossible : ${t.message ?: t.javaClass.simpleName}"))
            }
            runOnUiThread {
                games = result.games
                errors = result.errors
                scanned = true
                loading = false
            }
        }
    }

    /** Vide le cache d'images et relit tous les jeux. */
    private fun refresh() {
        val saved = prefs.getString("tree", null)
        if (saved == null) { pickFolder(); return }
        File(filesDir, "cache").deleteRecursively()
        load(Uri.parse(saved))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Plein écran immersif (barres masquées, réapparaissent en glissant depuis le bord)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        CrashLog.install(this)
        crash = CrashLog.read(this)
        prefs.getString("tree", null)?.let { load(Uri.parse(it)) }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    val c = crash
                    when {
                        c != null -> CrashScreen(c) {
                            CrashLog.clear(this@MainActivity)
                            crash = null
                        }
                        loading -> LoadingScreen()
                        games.isEmpty() -> EmptyScreen(scanned, errors) { pickFolder() }
                        else -> HomeScreen(
                            games = games,
                            errors = errors,
                            onChangeFolder = { pickFolder() },
                            onRefresh = { refresh() },
                        )
                    }
                }
            }
        }
    }
}

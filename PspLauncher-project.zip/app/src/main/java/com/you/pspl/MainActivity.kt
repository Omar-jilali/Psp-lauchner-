package com.you.pspl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.you.pspl.data.Game
import com.you.pspl.data.GameScanner
import com.you.pspl.player.Bgm
import com.you.pspl.ui.HomeScreen
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private var games by mutableStateOf(listOf<Game>())
    private var loading by mutableStateOf(false)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("tree", uri.toString()).apply()
            load(uri)
        }
    }

    private fun load(uri: Uri) {
        loading = true
        thread {
            val g = runCatching { GameScanner.scan(this, uri) }.getOrDefault(emptyList())
            runOnUiThread { games = g; loading = false }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs.getString("tree", null)?.let { load(Uri.parse(it)) }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    if (games.isEmpty()) {
                        Column(Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            if (loading) CircularProgressIndicator()
                            else Button(onClick = { picker.launch(null) }) {
                                Text("Choisir le dossier des ISO")
                            }
                        }
                    } else HomeScreen(games) { g -> Bgm.play(g?.music) }
                }
            }
        }
    }
    override fun onStop() { super.onStop(); Bgm.stop() }
}

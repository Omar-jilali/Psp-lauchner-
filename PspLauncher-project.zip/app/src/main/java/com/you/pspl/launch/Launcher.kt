package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.you.pspl.data.Game
import com.you.pspl.data.Platform

private val PPSSPP = listOf(
    "org.ppsspp.ppssppgold" to "org.ppsspp.ppsspp.PpssppActivity",
    "org.ppsspp.ppsspp" to "org.ppsspp.ppsspp.PpssppActivity",
)
private const val APS3E = "aenu.aps3e"

/** Lance le jeu dans le bon émulateur. Retourne false si l'émulateur est absent. */
fun launchGame(ctx: Context, g: Game): Boolean = when (g.platform) {
    Platform.PSP -> launchInPpsspp(ctx, g.uri)
    Platform.PS3 -> launchInAps3e(ctx, g.uri)
}

private fun launchInPpsspp(ctx: Context, iso: Uri): Boolean {
    for ((pkg, activity) in PPSSPP) {
        if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) continue
        val i = Intent(Intent.ACTION_VIEW).apply {
            setClassName(pkg, activity)
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
        return true
    }
    return false
}

/**
 * aPS3e : l'API d'intent n'est pas documentée, on essaie plusieurs formes
 * puis, en dernier recours, on ouvre simplement l'appli.
 */
private fun launchInAps3e(ctx: Context, uri: Uri): Boolean {
    val pm = ctx.packageManager
    val home = pm.getLaunchIntentForPackage(APS3E) ?: return false
    val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
    val attempts = listOf(
        Intent(Intent.ACTION_VIEW).setPackage(APS3E).setData(uri),
        Intent(Intent.ACTION_VIEW).setClassName(APS3E, "aenu.aps3e.EmulatorActivity")
            .setData(uri).putExtra("iso_uri", uri.toString()),
    )
    for (i in attempts) {
        i.addFlags(flags)
        if (runCatching { ctx.startActivity(i) }.isSuccess) return true
    }
    ctx.startActivity(home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    Toast.makeText(ctx, "aPS3e ouvert : lance le jeu depuis l'appli", Toast.LENGTH_LONG).show()
    return true
}

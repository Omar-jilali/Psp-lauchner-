package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Un émulateur connu. Si activity est null, on cible juste le package. */
data class Emu(val name: String, val pkg: String, val activity: String? = null)

val KNOWN_EMUS = listOf(
    Emu("PPSSPP Gold (PSP)", "org.ppsspp.ppssppgold", "org.ppsspp.ppsspp.PpssppActivity"),
    Emu("PPSSPP (PSP)", "org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity"),
    Emu("DuckStation (PS1)", "com.github.stenzek.duckstation"),
    Emu("NetherSX2 / AetherSX2 (PS2)", "xyz.aethersx2.android"),
    Emu("Dolphin (GameCube / Wii)", "org.dolphinemu.dolphinemu"),
    Emu("Flycast (Dreamcast)", "com.flycast.emulator"),
)

fun isInstalled(ctx: Context, e: Emu): Boolean =
    ctx.packageManager.getLaunchIntentForPackage(e.pkg) != null

fun installedEmus(ctx: Context): List<Emu> = KNOWN_EMUS.filter { isInstalled(ctx, it) }

/** La "porte" : lance l'émulateur choisi avec l'ISO. false si ça échoue. */
fun launchWith(ctx: Context, e: Emu, iso: Uri): Boolean {
    val i = Intent(Intent.ACTION_VIEW).apply {
        if (e.activity != null) setClassName(e.pkg, e.activity) else setPackage(e.pkg)
        setDataAndType(iso, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return runCatching { ctx.startActivity(i) }.isSuccess
}

/** Laisse Android proposer toutes les apps capables d'ouvrir le fichier. */
fun launchChooser(ctx: Context, iso: Uri): Boolean {
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(iso, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    return runCatching {
        ctx.startActivity(Intent.createChooser(i, "Ouvrir avec…"))
    }.isSuccess
}

// ---- Choix mémorisé (même fichier de préférences que MainActivity)
private const val KEY = "emu"

fun loadSavedPkg(ctx: Context): String? =
    ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString(KEY, null)

fun storeSavedPkg(ctx: Context, pkg: String?) {
    ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().apply {
        if (pkg == null) remove(KEY) else putString(KEY, pkg)
    }.apply()
}

package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.net.Uri

private val PPSSPP = listOf(
    "org.ppsspp.ppssppgold" to "org.ppsspp.ppsspp.PpssppActivity",
    "org.ppsspp.ppsspp" to "org.ppsspp.ppsspp.PpssppActivity",
)

/** La "porte" : lance PPSSPP avec l'ISO. Retourne false si PPSSPP est absent. */
fun launchInPpsspp(ctx: Context, iso: Uri): Boolean {
    for ((pkg, activity) in PPSSPP) {
        if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) continue
        val i = Intent(Intent.ACTION_VIEW).apply {
            setClassName(pkg, activity)
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                     Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
        return true
    }
    return false
}
